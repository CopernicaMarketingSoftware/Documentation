/**
 *  POMSOAPAPI
 */
public class Main 
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        // Create the main WebService object.
        api.POMSOAPAPI service = new api.POMSOAPAPI();
        
        // Create a port to the webservice object.
        api.POMPortType pom = service.getPOMPort();
        
        // Make sure the Web Service send back cookies. Otherwise we aren't logged in after the login request.
        ((javax.xml.ws.BindingProvider)pom).getRequestContext().put(javax.xml.ws.BindingProvider.SESSION_MAINTAIN_PROPERTY,true);
        
        // Enable compression
         ((javax.xml.ws.BindingProvider)pom).getRequestContext().put(MessageContext.HTTP_REQUEST_HEADERS, Collections.singletonMap("Accept-Encoding",Collections.singletonList("gzip")));

        // Create new login parameter object
        api.InputLogin login_parameters = new api.InputLogin();
    
        // Setup the login parameters.
        login_parameters.setAccount("Account");         // Setup the account
        login_parameters.setUsername("Username");       // Setup the username
        login_parameters.setPassword("********");       // Setup the password.
    
        // Use the try .. catch system to login.
        try
        {
            // Login using the login parameters.
            pom.login(login_parameters);
            
            // We arrive here when the login has been a succes.
            System.out.println("Logged in.");
        }
        catch (Exception ex)
        {
            // The login was wrong and threw a exception, that's why we arrived here.
            // We print the error message to get some feedback.
            System.out.println(ex.getMessage());
        }    
                
        // Create database 'Fictional Persons'        
        api.InputAccountCreateDatabase parameters = new api.InputAccountCreateDatabase();
        parameters.setName("Fictional Persons");                    // The name of the future database.
        api.Result result = pom.accountCreateDatabase(parameters);  // Execute the command and store the result.
        
        // Retrieve the newly created database from the Result object.
        api.Database database = result.getDatabase();
        
        // Create fields for the database
        api.InputDatabaseCreateField field = new api.InputDatabaseCreateField();
        
        // Create the first name field.
        field.setId(database.getId()); // Give the Database id, so the field get's created inside the new database
        field.setName("FirstName");    // Setup the field name
        field.setDisplay(true);         // Make it appear on the overview (in the web application)                
        pom.databaseCreateField(field); // Create the field.
        
        // Create the last name field.
        field.setId(database.getId()); // Give the Database id, so the field get's created inside the new database        
        field.setName("LastName");     // Setup the fieldname
        field.setDisplay(true);         // Make it appear on the overview (in the web application)                
        pom.databaseCreateField(field); // Create the field.
    
        // Create the e-mail field.
        field.setId(database.getId()); // Give the Database id, so the field get's created inside the new database        
        field.setName("Email");             // Setup the fieldname
        field.setDisplay(true);             // Make it appear on the overview (in the web application)                
        field.setSpecialcontent("email");   // Make sure it's an E-mail field, so we can send mailings.
        pom.databaseCreateField(field);     // Create the field.
        
        // Create a fictional person.
        api.InputDatabaseCreateProfile profile = new api.InputDatabaseCreateProfile();
        profile.setId(database.getId());    // Give the Database id, so the person get's created inside the new database
        
        // The fields are given trough a Map object. A map consists of multiple Pair objects.
        api.Map fields = new api.Map();
        
        // We need to create for each field a Pair object.
        api.Pair pair1 = new api.Pair();
        api.Pair pair2 = new api.Pair();
        api.Pair pair3 = new api.Pair();
        pair1.setKey("FirstName");          // The key would be the name of the field.
        pair1.setValue("Piet");             // The value would be the value of the field.
        
        pair2.setKey("LastName");           // The key would be the name of the field.
        pair2.setValue("Papier");           // The value would be the value of the field.
        
        pair3.setKey("Email");              // The key would be the name of the field.
        pair3.setValue("piet@papier.nl");   // The value would be the value of the field.
        
        // Add the pairs to the fields map.
        fields.getPair().add(pair1);
        fields.getPair().add(pair2);
        fields.getPair().add(pair3);
    
        // Add the fields map to the profile.
        profile.setFields(fields);
        
        // And finally; Create the profile.
        result = pom.databaseCreateProfile(profile);
    
        // Save the first profile from the results
        Api.Profile profile1 = result.getProfile();
        
        // Create a second fictional person.
        profile = new api.InputDatabaseCreateProfile();
        profile.setId(database.getId());    // Give the Database id, so the person get's created inside the new database
        
        // The fields are given trough a Map object. A map consists of multiple Pair objects.
        fields = new api.Map();
        
        // We need to create for each field a Pair object.
        pair1 = new api.Pair();
        pair2 = new api.Pair();
        pair3 = new api.Pair();
        pair1.setKey("FirstName");         // The key would be the name of the field.
        pair1.setValue("Ed");              // The value would be the value of the field.
        
        pair2.setKey("LastName");          // The key would be the name of the field.
        pair2.setValue("Emmer");           // The value would be the value of the field.
        
        pair3.setKey("Email");             // The key would be the name of the field.
        pair3.setValue("ed@emmer.nl");     // The value would be the value of the field.
        
        // Add the pairs to the fields map.
        fields.getPair().add(pair1);
        fields.getPair().add(pair2);
        fields.getPair().add(pair3);
    
        // Add the fields map to the profile.
        profile.setFields(fields);
        
        // And finally; Create the profile.
        result = pom.databaseCreateProfile(profile);
    
        // Save the second profile from the results
        Api.Profile profile2 = result.getProfile();
        
        api.InputProfileRemove removeparameters = new api.InputProfileRemove(); 
        removeparameters.setId(profile2.getId());       // set the id of the profile that will be removed.
        pom.profileRemove(removeparameters);// execute call
        
        api.InputProfileUpdateFields updateparameters = new api.InputProfileUpdateFields();
        updateparameters.setId(profile1.getId());       // set the id of the profile that will be updated.
        
        // The fields are given trough a Map object. A map consists of multiple Pair objects.
        fields = new api.Map();
        
        // We need to create for each field a Pair object.
        pair1 = new api.Pair();
        pair1.setKey("Email");
        pair1.setValue("piet.papier@example.com");
        fields.getPair().add(pair1);
        
        // Add th efields map to the parameter
        updateparameters.setFields(fields);
        pom.profileUpdateFields(updateparameters);
    }
