﻿using System.Web.UI;

namespace CopernicaLibraryImplementationExample.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}