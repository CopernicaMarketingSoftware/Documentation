﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CopernicaLibraryImplementationExample.Startup))]
namespace CopernicaLibraryImplementationExample
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
