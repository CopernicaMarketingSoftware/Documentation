﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CopernicaLibraryImplementationExample.Models;
using CopernicaWrapper;
using CopernicaWrapper.Interfaces.Handlers;

namespace CopernicaLibraryImplementationExample
{
    public class CopernicaHandler : Copernica<CopernicaHandler>, ICopernicaHandlerBase
    {
        public CopernicaHandler()
            : base("Access token here!")
        {

        }

        public void RegisterDataItems()
        {
            RegisterDataItem(new Client());
        }
    }
}