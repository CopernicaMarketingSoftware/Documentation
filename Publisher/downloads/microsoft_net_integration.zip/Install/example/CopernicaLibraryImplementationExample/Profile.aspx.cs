﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CopernicaLibraryImplementationExample.Models;
using CopernicaWrapper.Data;

namespace CopernicaLibraryImplementationExample
{
    public partial class Profile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Add_Profile(object sender, EventArgs e)
        {
            //Create the client
            var client = new Client { ID = Int32.Parse(ID.Text), Name = ProfileName.Text, Email = Email.Text };
            
            try
            {
                //Add the client profile
                CopernicaHandler.Instance.Add(client);
                StatusLabel.Text = "The profile has been added";
            }
            catch (CopernicaException ex)
            {
                StatusLabel.Text = ex.Message;
            }
        } 
        
        protected void Delete_Profile(object sender, EventArgs e)
        {
            //Create the client. Only the CopernicaKeyField property is required to delete the profile.
            var client = new Client { ID = Int32.Parse(ID.Text) };
            
            try
            {
                //Delete the client profile
                CopernicaHandler.Instance.Delete(client);
                StatusLabel.Text = "The profile has been deleted";
            }
            catch (CopernicaException ex)
            {
                StatusLabel.Text = ex.Message;
            }
        } 
        
        protected void Update_Profile(object sender, EventArgs e)
        {
            //Create the client
            var client = new Client { ID = Int32.Parse(ID.Text), Name = ProfileName.Text, Email = Email.Text };
            
            try
            {
                //Update the client profile
                CopernicaHandler.Instance.Update(client);
                StatusLabel.Text = "The profile has been updated";
            }
            catch (CopernicaException ex)
            {
                StatusLabel.Text = ex.Message;
            }
        }

        
    }
}