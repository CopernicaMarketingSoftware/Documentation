<?php

/*
*	LIZENZbedingungen bitte hier 
*/

/*
*	BUGS:
*
*	TODO:
*	- Anforderungen von Copernica Passwörten? Erlaubte Zeichen? Min/Max Länge -> $this->isPasswd()
*	- Standardsprache (Englisch) überprüfen
*	- soaptest.php löschen
*/

/*
-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 16. Januar 2012 um 09:56
-- Server Version: 5.5.8
-- PHP-Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Datenbank: `prestashop_gc_edition_1470`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ps_copernica`
--

CREATE TABLE IF NOT EXISTS `ps_copernica` (
  `field` varchar(32) NOT NULL,
  `collection` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `type` enum('text','numeric','email','phone','datetime','select','big') NOT NULL DEFAULT 'text',
  `length` int(10) NOT NULL,
  `display` tinyint(1) NOT NULL DEFAULT '1',
  `ready` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id_copernica` (`collection`,`field`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `ps_copernica`
--

INSERT INTO `ps_copernica` (`field`, `collection`, `name`, `type`, `length`, `display`, `ready`) VALUES
('active', '', 'Active', 'numeric', 1, 1, 1),
('birthday', '', 'Birthday', 'text', 12, 1, 1),
('date_add', '', 'Date_Add', 'datetime', 0, 1, 1),
('date_upd', '', 'Date_Update', 'datetime', 0, 1, 1),
('deleted', '', 'Deleted', 'numeric', 1, 1, 1),
('email', '', 'Email', 'email', 0, 1, 1),
('firstname', '', 'Firstname', 'text', 32, 1, 1),
('id_customer', '', 'Customer_ID', 'numeric', 10, 1, 1),
('id_gender', '', 'Gender', 'numeric', 10, 1, 1),
('lastname', '', 'Lastname', 'text', 32, 1, 1),
('newsletter', '', 'Newsletter', 'numeric', 1, 1, 1),
('optin', '', 'Optin', 'numeric', 1, 1, 1),
('active', 'Address', 'Active', 'numeric', 1, 1, 1),
('address1', 'Address', 'Address_1', 'text', 128, 1, 1),
('address2', 'Address', 'Address_2', 'text', 128, 1, 1),
('city', 'Address', 'City', 'text', 64, 1, 1),
('company', 'Address', 'Company', 'text', 32, 1, 1),
('date_add', 'Address', 'Date_Add', 'datetime', 0, 1, 1),
('date_upd', 'Address', 'Date_update', 'datetime', 0, 1, 1),
('deleted', 'Address', 'Deleted', 'numeric', 1, 1, 1),
('dni', 'Address', 'DNI', 'text', 16, 1, 1),
('firstname', 'Address', 'Firstname', 'text', 32, 1, 1),
('id_address', 'Address', 'Address_ID', 'numeric', 10, 1, 1),
('id_country', 'Address', 'Country_ID', 'numeric', 10, 1, 1),
('id_customer', 'Address', 'Customer_ID', 'numeric', 10, 1, 1),
('id_state', 'Address', 'State_ID', 'numeric', 10, 1, 1),
('lastname', 'Address', 'Lastname', 'text', 32, 1, 1),
('phone', 'Address', 'Phone', 'phone', 0, 1, 1),
('phone_mobile', 'Address', 'Mobile_Phone', 'phone', 0, 1, 1),
('postcode', 'Address', 'Postcode', 'text', 12, 1, 1),
('vat_number', 'Address', 'VAT', 'text', 32, 1, 1),
('date_add', 'Cart', 'Date_Add', 'datetime', 0, 1, 1),
('date_upd', 'Cart', 'Date_Update', 'datetime', 0, 1, 1),
('id_address_delivery', 'Cart', 'Address_Delivery_ID', 'numeric', 10, 1, 1),
('id_address_invoice', 'Cart', 'Address_Invoice_ID', 'numeric', 10, 1, 1),
('id_carrier', 'Cart', 'Carrier_ID', 'numeric', 10, 1, 1),
('id_cart', 'Cart', 'Cart_ID', 'numeric', 10, 1, 1),
('id_customer', 'Cart', 'Customer_ID', 'numeric', 10, 1, 1),
('cart_quantity', 'CartProducts', 'Quantity', 'numeric', 10, 1, 1),
('category', 'CartProducts', 'Category', 'text', 128, 1, 1),
('customization_quantity', 'CartProducts', 'Customization_Quantity', 'numeric', 10, 1, 1),
('id_customization', 'CartProducts', 'Customization_ID', 'numeric', 10, 1, 1),
('id_product', 'CartProducts', 'Customer_ID', 'numeric', 10, 1, 1),
('id_product_attribute', 'CartProducts', 'Attribute_ID', 'numeric', 10, 1, 1),
('image', 'CartProducts', 'Image', 'text', 128, 1, 1),
('name', 'CartProducts', 'Name', 'text', 128, 1, 1),
('reference', 'CartProducts', 'Reference', 'text', 32, 1, 1),
('total', 'CartProducts', 'Total', 'text', 21, 1, 1),
('url', 'CartProducts', 'Url', 'text', 128, 1, 1),
('weight', 'CartProducts', 'Weight', 'text', 10, 1, 1),
('image', 'OrderProducts', 'Image', 'text', 128, 1, 1),
('product_attribute_id', 'OrderProducts', 'Attribute_ID', 'numeric', 10, 1, 1),
('product_id', 'OrderProducts', 'Product_ID', 'numeric', 10, 1, 1),
('product_name', 'OrderProducts', 'Name', 'text', 128, 1, 1),
('product_quantity', 'OrderProducts', 'Quantity', 'numeric', 10, 1, 1),
('product_reference', 'OrderProducts', 'Reference', 'text', 32, 1, 1),
('product_weight', 'OrderProducts', 'Weight', 'text', 10, 1, 1),
('total_price', 'OrderProducts', 'Total', 'text', 21, 1, 1),
('url', 'OrderProducts', 'Url', 'text', 128, 1, 1),
('date_add', 'Orders', 'Date_Add', 'datetime', 0, 1, 1),
('date_upd', 'Orders', 'Date_Update', 'datetime', 0, 1, 1),
('id_address_delivery', 'Orders', 'Address_Delivery_ID', 'numeric', 10, 1, 1),
('id_address_invoice', 'Orders', 'Address_Invoice_ID', 'numeric', 10, 1, 1),
('id_carrier', 'Orders', 'Carrier_ID', 'numeric', 10, 1, 1),
('id_cart', 'Orders', 'Cart_ID', 'numeric', 10, 1, 1),
('id_customer', 'Orders', 'Customer_ID', 'numeric', 10, 1, 1),
('id_order', 'Orders', 'Order_ID', 'numeric', 10, 1, 1),
('payment', 'Orders', 'Payment_Method', 'text', 128, 1, 1),
('total_paid', 'Orders', 'Total_Paid', 'text', 21, 1, 1),
('total_products', 'Orders', 'Total_Products', 'numeric', 1, 1, 1);



*/

// Wenn das Komplettsystem nicht gestartet ist, soll beim Einzelaufruf dieser Datei nichts passieren
if (!defined('_PS_VERSION_'))
	exit;

// Copernica SOAP Api einbinden
require_once(_PS_MODULE_DIR_.'copernica/soapclient.php');
	
// Klasse Copernica
class Copernica extends Module {
	
	public  $copernica_min_ps_version = '1.4.4.0'; // Minimal benötigte PS Version
	
	private $_soapclient = null;                   // Die Copernica API instanz
	private $_cache = array();                     // Der Cache
	private $_language = 0;
	
	// Konstruktor
	function __construct() {
		
	 	$this->name    = 'copernica';             // Modulname = Modulordner = Klassenname = Dateiname
	 	$this->tab     = 'advertising_marketing'; // Wird in welchem Modultab angezeigt?
	 	$this->version = '0.1';                   // Version
		$this->author  = 'Onlineshop-Module.de';  // Erstellt von
        
	 	parent::__construct();                    // Grundfunktionen des Moduls initialisieren
		
		$this->displayName     = $this->l('Copernica E-Mail Marketing');                                               // Angezeigter Name im BO
        $this->description     = $this->l('Allows yout to connect your PrestaShop to an Copernica Marketing account'); // Angezeigte Beschreiung in BO
		$this->beforeUninstall = $this->l('Do you really want to delete this module an all it\'s configuration?');     // Warnhinweis beim löschen im BO
		
		$this->checkRequirements();
		
		$this->_language = Configuration::get('PS_LANG_DEFAULT');
		
	}
	
	// Wird bei der Installation des Moduls ansich ausgeführt
    function install() {
		
		// Hauptmodul installieren
        if (!parent::install())
			return false;
		
		// Datenbanktabelle hinzufügen
		Db::getInstance()->Execute("
		CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."copernica` (
			`field` varchar(32) NOT NULL,
			`collection` varchar(32) NOT NULL,
			`name` varchar(32) NOT NULL,
			`type` enum('text','numeric','email','phone','datetime','select','big') NOT NULL DEFAULT 'text',
			`length` int(10) NOT NULL,
			`display` tinyint(1) NOT NULL DEFAULT '1',
			`ready` tinyint(1) NOT NULL DEFAULT '0',
			UNIQUE KEY `id_copernica` (`collection`,`field`)
		) ENGINE="._MYSQL_ENGINE_
		);
		
		// Datensätze eintragen
		Db::getInstance()->Execute("
		INSERT INTO `"._DB_PREFIX_."copernica` (`field`, `collection`, `name`, `type`, `length`, `display`, `ready`) VALUES
			('active', '', 'Active', 'numeric', 1, 1, 1),
			('birthday', '', 'Birthday', 'text', 12, 1, 1),
			('date_add', '', 'Date_Add', 'datetime', 0, 1, 1),
			('date_upd', '', 'Date_Update', 'datetime', 0, 1, 1),
			('deleted', '', 'Deleted', 'numeric', 1, 1, 1),
			('email', '', 'Email', 'email', 0, 1, 1),
			('firstname', '', 'Firstname', 'text', 32, 1, 1),
			('id_customer', '', 'Customer_ID', 'numeric', 10, 1, 1),
			('id_gender', '', 'Gender', 'numeric', 10, 1, 1),
			('lastname', '', 'Lastname', 'text', 32, 1, 1),
			('newsletter', '', 'Newsletter', 'numeric', 1, 1, 1),
			('optin', '', 'Optin', 'numeric', 1, 1, 1),
			('active', 'Address', 'Active', 'numeric', 1, 1, 1),
			('address1', 'Address', 'Address_1', 'text', 128, 1, 1),
			('address2', 'Address', 'Address_2', 'text', 128, 1, 1),
			('city', 'Address', 'City', 'text', 64, 1, 1),
			('company', 'Address', 'Company', 'text', 32, 1, 1),
			('date_add', 'Address', 'Date_Add', 'datetime', 0, 1, 1),
			('date_upd', 'Address', 'Date_update', 'datetime', 0, 1, 1),
			('deleted', 'Address', 'Deleted', 'numeric', 1, 1, 1),
			('dni', 'Address', 'DNI', 'text', 16, 1, 1),
			('firstname', 'Address', 'Firstname', 'text', 32, 1, 1),
			('id_address', 'Address', 'Address_ID', 'numeric', 10, 1, 1),
			('id_country', 'Address', 'Country_ID', 'numeric', 10, 1, 1),
			('id_customer', 'Address', 'Customer_ID', 'numeric', 10, 1, 1),
			('id_state', 'Address', 'State_ID', 'numeric', 10, 1, 1),
			('lastname', 'Address', 'Lastname', 'text', 32, 1, 1),
			('phone', 'Address', 'Phone', 'phone', 0, 1, 1),
			('phone_mobile', 'Address', 'Mobile_Phone', 'phone', 0, 1, 1),
			('postcode', 'Address', 'Postcode', 'text', 12, 1, 1),
			('vat_number', 'Address', 'VAT', 'text', 32, 1, 1),
			('date_add', 'Cart', 'Date_Add', 'datetime', 0, 1, 1),
			('date_upd', 'Cart', 'Date_Update', 'datetime', 0, 1, 1),
			('id_address_delivery', 'Cart', 'Address_Delivery_ID', 'numeric', 10, 1, 1),
			('id_address_invoice', 'Cart', 'Address_Invoice_ID', 'numeric', 10, 1, 1),
			('id_carrier', 'Cart', 'Carrier_ID', 'numeric', 10, 1, 1),
			('id_cart', 'Cart', 'Cart_ID', 'numeric', 10, 1, 1),
			('id_customer', 'Cart', 'Customer_ID', 'numeric', 10, 1, 1),
			('cart_quantity', 'CartProducts', 'Quantity', 'numeric', 10, 1, 1),
			('category', 'CartProducts', 'Category', 'text', 128, 1, 1),
			('customization_quantity', 'CartProducts', 'Customization_Quantity', 'numeric', 10, 1, 1),
			('id_customization', 'CartProducts', 'Customization_ID', 'numeric', 10, 1, 1),
			('id_product', 'CartProducts', 'Customer_ID', 'numeric', 10, 1, 1),
			('id_product_attribute', 'CartProducts', 'Attribute_ID', 'numeric', 10, 1, 1),
			('image', 'CartProducts', 'Image', 'text', 128, 1, 1),
			('name', 'CartProducts', 'Name', 'text', 128, 1, 1),
			('reference', 'CartProducts', 'Reference', 'text', 32, 1, 1),
			('total', 'CartProducts', 'Total', 'text', 21, 1, 1),
			('url', 'CartProducts', 'Url', 'text', 128, 1, 1),
			('weight', 'CartProducts', 'Weight', 'text', 10, 1, 1),
			('image', 'OrderProducts', 'Image', 'text', 128, 1, 1),
			('product_attribute_id', 'OrderProducts', 'Attribute_ID', 'numeric', 10, 1, 1),
			('product_id', 'OrderProducts', 'Product_ID', 'numeric', 10, 1, 1),
			('product_name', 'OrderProducts', 'Name', 'text', 128, 1, 1),
			('product_quantity', 'OrderProducts', 'Quantity', 'numeric', 10, 1, 1),
			('product_reference', 'OrderProducts', 'Reference', 'text', 32, 1, 1),
			('product_weight', 'OrderProducts', 'Weight', 'text', 10, 1, 1),
			('total_price', 'OrderProducts', 'Total', 'text', 21, 1, 1),
			('url', 'OrderProducts', 'Url', 'text', 128, 1, 1),
			('date_add', 'Orders', 'Date_Add', 'datetime', 0, 1, 1),
			('date_upd', 'Orders', 'Date_Update', 'datetime', 0, 1, 1),
			('id_address_delivery', 'Orders', 'Address_Delivery_ID', 'numeric', 10, 1, 1),
			('id_address_invoice', 'Orders', 'Address_Invoice_ID', 'numeric', 10, 1, 1),
			('id_carrier', 'Orders', 'Carrier_ID', 'numeric', 10, 1, 1),
			('id_cart', 'Orders', 'Cart_ID', 'numeric', 10, 1, 1),
			('id_customer', 'Orders', 'Customer_ID', 'numeric', 10, 1, 1),
			('id_order', 'Orders', 'Order_ID', 'numeric', 10, 1, 1),
			('payment', 'Orders', 'Payment_Method', 'text', 128, 1, 1),
			('total_paid', 'Orders', 'Total_Paid', 'text', 21, 1, 1),
			('total_products', 'Orders', 'Total_Products', 'numeric', 1, 1, 1);

		");
		
		// Konfigurationen anlegen
		if(
			!Configuration::updateValue('COPERNICA_HOSTNAME', '') or
			!Configuration::updateValue('COPERNICA_USERNAME', '') or
			!Configuration::updateValue('COPERNICA_ACCOUNT', '') or
			!Configuration::updateValue('COPERNICA_PASSWORD', '') or
			!Configuration::updateValue('COPERNICA_DBNAME', '') or
			!Configuration::updateValue('COPERNICA_STEP2_COMPLETE', '0') or
			!Configuration::updateValue('COPERNICA_STEP3_COMPLETE', '0') or
			!Configuration::updateValue('COPERNICA_UPD', '00-00-00 00:00:00') 
		) {
			return false;
		}
		
		// Wenn alles korrekt installiert
		return true;
		
    }
	
	// Wird bei der deinstallation des Moduls ausgeführt
	function uninstall() {
		
		// Hauptmodul deinstallieren
		if (!parent::uninstall())
			return false;
		
		// DAtenbanktabelle löschen
		Db::getInstance()->Execute('DROP TABLE '._DB_PREFIX_.'copernica');
		
		// Konfigurationen löschen
		if(
			!Configuration::deleteByName('COPERNICA_HOSTNAME') or 
			!Configuration::deleteByName('COPERNICA_USERNAME') or 
			!Configuration::deleteByName('COPERNICA_ACCOUNT') or 
			!Configuration::deleteByName('COPERNICA_PASSWORD') or
			!Configuration::deleteByName('COPERNICA_DBNAME') or
			!Configuration::deleteByName('COPERNICA_STEP2_COMPLETE') or
			!Configuration::deleteByName('COPERNICA_STEP3_COMPLETE') or
			!Configuration::deleteByName('COPERNICA_UPD')
		)  {
			return false;
		}
		
		// Wenn Deinstallation erfolgreich
		return true;
		
	}
	
	/*
	*	Hooks
	*/
	
	/*
	*	Custom Functions
	*/
	
	// Ist der Copernica Server erreichbar?
	public function serverAvailable($hostname='') {
		
		if(empty($hostname))
			$hostname = Configuration::get('COPERNICA_HOSTNAME');
		
		$hostname .= '?SOAPAPI=WSDL';
		
		if (ini_get('allow_url_fopen') == '1') {
			
            if (@file_get_contents($hostname, NULL, NULL, 0, 1)) {
				
                $headers = get_headers($hostname, 1);
				
                if(@strpos($headers['Content-Type'], 'text/xml') !== false)
					return true;
                else
					return false;
				
            }
            else
				return false;
			
        }
        else {
			
            $ch = curl_init($hostname);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $data = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
            curl_close($ch);
			
            if($httpCode >= 200 and $httpCode < 300 and strpos($contentType, 'text/xml') !== false)
				return true;
            else
				return false;
			
		}
		
    }
	
	public function checkRequirements() {
		
		$warnings = array();
		
		// Wenn Mindestvoraussetzungen nicht erfüllt
		
		if(!version_compare(_PS_VERSION_, $this->copernica_min_ps_version, '>='))
			$warnings[] = $this->l('Your PrestaShop Version (')._PS_VERSION_.$this->l(') is not compatible with this Corpernica Module!');
		
		if(!extension_loaded('soap')) {
			$warnings[] = $this->l('SOAP extension is not available!');
		}
		
		if (!function_exists('curl_version') && !ini_get('allow_url_fopen')) {
			$warnings[] = $this->l('CURL or FOPEN are not allowed!');
		}
		
		if($hostname = Configuration::get('COPERNICA_HOSTNAME') and !empty($hostname) and !$this->serverAvailable()) {
			$warnings[] = $this->l('Can\'t connect to the Copernica host! Please check the \'hostname\'.');
		}
		
		if(
			$config = Configuration::getMultiple(array('COPERNICA_HOSTNAME', 'COPERNICA_USERNAME', 'COPERNICA_ACCOUNT', 'COPERNICA_PASSWORD')) 
			and !empty($config['COPERNICA_HOSTNAME']) 
			and !empty($config['COPERNICA_USERNAME']) 
			and !empty($config['COPERNICA_ACCOUNT']) 
			and !empty($config['COPERNICA_PASSWORD']) 
			and !$this->_connect()
		) {
			$warnings[] = $this->l('Can\'t connect to the Copernica host! Please check your login informations.');
		}
		
		if(count($warnings) > 0) {
			$this->warning = '<ul><li>'.implode('</li><li>', $warnings).'</li></ul>';
			return false;
		}
		
		return true;
		
	}
	
	private function _getCustomerData() {
		
		$fields = $this->_getFieldsFromDB('');
		$fieldstring = '';
		
		foreach($fields as $field)
			$fieldstring .= $field['field'].', ';
		
		$fieldstring = substr($fieldstring, 0, -2);
		
		$sql = "
		SELECT ".$fieldstring."
		FROM `"._DB_PREFIX_."customer` 
		WHERE date_upd > '".Configuration::get('COPERNICA_UPD')." '
		AND is_guest != '1'
		AND active = '1'
		";
		
		return DB::getInstance()->ExecuteS($sql);
		
	}
	
	private function _getAddressData() {
		
		$fields = $this->_getFieldsFromDB('Address');
		$fieldstring = '';
		
		foreach($fields as $field)
			$fieldstring .= 'a.'.$field['field'].', ';
		
		$fieldstring = substr($fieldstring, 0, -2);
		
		$sql = "
		SELECT ".$fieldstring." 
		FROM `"._DB_PREFIX_."address` AS a
		CROSS JOIN `"._DB_PREFIX_."customer` AS c ON (c.id_customer=a.id_customer AND c.is_guest != '1' AND c.active = '1')
		WHERE a.date_upd > '".Configuration::get('COPERNICA_UPD')."'
		";
		
		return DB::getInstance()->ExecuteS($sql);
		
	}
	
	private function _getCartData() {
		
		$fields = $this->_getFieldsFromDB('Cart');
		$fieldstring = '';
		
		foreach($fields as $field)
			$fieldstring .= 'c.'.$field['field'].', ';
		
		$fieldstring = substr($fieldstring, 0, -2);
		
		$sql = "
		SELECT ".$fieldstring." 
		FROM `"._DB_PREFIX_."cart` AS c
		CROSS JOIN `"._DB_PREFIX_."customer` AS cu ON (cu.id_customer=c.id_customer AND cu.is_guest != '1' AND cu.active = '1')
		WHERE c.date_upd > '".Configuration::get('COPERNICA_UPD')."'
		";
		
		return DB::getInstance()->ExecuteS($sql);
		
	}
	
	private function _getCartProductsData() {
		
		$data = array();
		$link = new Link();
		
		$sql = "
		SELECT c.id_cart, c.id_customer 
		FROM `"._DB_PREFIX_."cart` AS c
		CROSS JOIN `"._DB_PREFIX_."customer` AS cu ON (cu.id_customer=c.id_customer AND cu.is_guest != '1' AND cu.active = '1')
		WHERE c.date_upd > '".Configuration::get('COPERNICA_UPD')."'
		";
		
		$carts = DB::getInstance()->ExecuteS($sql);
		
		foreach($carts as $a) {
			
			$cart = new Cart($a['id_cart']);
			$products = $cart->getProducts(true);
			
			foreach($products as $b) {
				
				$product = new Product($b['id_product'], true, $this->_language);
				
				$b['url'] = $product->getLink();
				$b['image'] = $link->getImageLink($b['link_rewrite'], $b['id_image'], 'small');
				
				$data[$a['id_customer']][$a['id_cart']][] = $b;
				
			}

		}
		
		return $data;
		
	}
	
	private function _getOrderData() {
		
		$fields = $this->_getFieldsFromDB('Orders');
		$fieldstring = '';
		
		foreach($fields as $field)
			$fieldstring .= 'o.'.$field['field'].', ';
		
		$fieldstring = substr($fieldstring, 0, -2);
		
		$sql = "
		SELECT ".$fieldstring." 
		FROM `"._DB_PREFIX_."orders` AS o
		CROSS JOIN `"._DB_PREFIX_."customer` AS cu ON (cu.id_customer=o.id_customer AND cu.is_guest != '1' AND cu.active = '1')
		WHERE o.date_upd > '".Configuration::get('COPERNICA_UPD')."'
		";
		
		return DB::getInstance()->ExecuteS($sql);
		
	}
	
	private function _getOrderProductsData() {
		
		$data = array();
		$link = new Link();
		
		$sql = "
		SELECT o.id_order, o.id_customer 
		FROM `"._DB_PREFIX_."orders` AS o
		CROSS JOIN `"._DB_PREFIX_."customer` AS cu ON (cu.id_customer=o.id_customer AND cu.is_guest != '1' AND cu.active = '1')
		WHERE o.date_upd > '".Configuration::get('COPERNICA_UPD')."'
		";
		
		$orders = DB::getInstance()->ExecuteS($sql);
		
		foreach($orders as $a) {
			
			$order = new Order($a['id_order']);
			$products = $order->getProducts();
			
			foreach($products as $b) {
				
				$product = new Product($b['product_id'], true, $this->_language);
				
				$cover = Product::getCover($b['product_id']);
				
				$b['url'] = $product->getLink();
				$b['image'] = $link->getImageLink($product->link_rewrite, $b['product_id'].'-'.$cover['id_image'], 'small');
				
				$data[$a['id_customer']][$a['id_order']][] = $b;
				
			}
			
		}
		
		return $data;
		
	}
	
	private function _executeSync() {
		
		$errors = array();
		
		$customers     = $this->_getCustomerData();
		$addresses     = $this->_getAddressData();
		$carts         = $this->_getCartData();
		$cartproducts  = $this->_getCartProductsData();
		$orders        = $this->_getOrderData();
		$orderproducts = $this->_getOrderProductsData();
		
		$fields = $this->_getFieldsFromDB('');
		
		$database = $this->_databaseExists();
		
		foreach($customers as $customer) {
		
			$values = array();
			
			foreach($fields as $field) {
				$values[$field['name']] =  $customer[$field['field']];
			}
			
			if($profile = $this->_profileExists($customer['id_customer'])) {
				$this->_soapclient->Profile_updateFields(array(
					'id' => $profile->id,
					'fields' => $values
				));
			}
			else {
				$profile = $this->_soapclient->Database_createProfile(array(
					'id' => $database->id,
					'fields' => $values
				));
			}
			
		}
		
		$fields = $this->_getFieldsFromDB('Address');
		
		foreach($addresses as $address) {
			
			$values = array();
			
			foreach($fields as $field) {
				$values[$field['name']] = $address[$field['field']];
			}
			
			if(!$profile = $this->_profileExists($address['id_customer']))
				continue;
			
			if($subprofile = $this->_subprofileExists('Address', $profile, $address['id_address'])) {
				$this->_soapclient->SubProfile_updateFields(array(
					'id' => $subprofile->id,
					'fields' => $values
				));
			}
			else {
				
				$collection = $this->_collectionExists('Address');
				
				$this->_soapclient->Profile_createSubProfile(array(
					'id'         => $profile->id,
					'collection' => $collection,
					'fields'     => $values
				));
				
			}
			
		}
		
		$fields = $this->_getFieldsFromDB('Cart');
		
		foreach($carts as $cart) {
		
			$values = array();
			
			foreach($fields as $field) {
				$values[$field['name']] = $cart[$field['field']];
			}
			
			if(!$profile = $this->_profileExists($cart['id_customer']))
				continue;
			
			if($subprofile = $this->_subprofileExists('Cart', $profile, $cart['id_cart'])) {
				$this->_soapclient->SubProfile_updateFields(array(
					'id' => $subprofile->id,
					'fields' => $values
				));
			}
			else {
				
				$collection = $this->_collectionExists('Cart');
				
				$this->_soapclient->Profile_createSubProfile(array(
					'id'         => $profile->id,
					'collection' => $collection,
					'fields'     => $values
				));
				
			}
			
		}
		
		$fields = $this->_getFieldsFromDB('CartProducts');
		
		foreach($cartproducts as $customer_id => $carts) {
			
			foreach($carts as $cart_id => $products) {
				
				foreach($products as $product) {
					
					$values = array();
					
					foreach($fields as $field) {
						$values[$field['name']] = $product[$field['field']];
					}
					
					if(!$profile = $this->_profileExists($customer_id))
						continue;
					
					if($subprofile = $this->_subprofileExists('CartProducts', $profile, $product['id_product'])) {
						$this->_soapclient->SubProfile_updateFields(array(
							'id' => $subprofile->id,
							'fields' => $values
						));
					}
					else {
						
						$collection = $this->_collectionExists('CartProducts');
						
						$this->_soapclient->Profile_createSubProfile(array(
							'id'         => $profile->id,
							'collection' => $collection,
							'fields'     => $values
						));
						
					}
				}
			}
			
		}
		
		$fields = $this->_getFieldsFromDB('Orders');
		
		foreach($orders as $order) {
		
			$values = array();
			
			foreach($fields as $field) {
				$values[$field['name']] =  $order[$field['field']];
			}
			
			if(!$profile = $this->_profileExists($order['id_customer']))
				continue;
			
			if($subprofile = $this->_subprofileExists('Orders', $profile, $order['id_order'])) {
				$this->_soapclient->SubProfile_updateFields(array(
					'id' => $subprofile->id,
					'fields' => $values
				));
			}
			else {
				
				$collection = $this->_collectionExists('Orders');
				
				$this->_soapclient->Profile_createSubProfile(array(
					'id'         => $profile->id,
					'collection' => $collection,
					'fields'     => $values
				));
				
			}
			
		}
		
		$fields = $this->_getFieldsFromDB('OrderProducts');
		
		foreach($orderproducts as $customer_id => $orders) {
			
			foreach($orders as $order_id => $products) {
				
				foreach($products as $product) {
				
					$values = array();
					
					foreach($fields as $field) {
						$values[$field['name']] =  $product[$field['field']];
					}
					
					if(!$profile = $this->_profileExists($customer_id))
						continue;
					
					if($subprofile = $this->_subprofileExists('OrderProducts', $profile, $product['product_id'])) {
						$this->_soapclient->SubProfile_updateFields(array(
							'id' => $subprofile->id,
							'fields' => $values
						));
					}
					else {
						
						$collection = $this->_collectionExists('OrderProducts');
						
						$this->_soapclient->Profile_createSubProfile(array(
							'id'         => $profile->id,
							'collection' => $collection,
							'fields'     => $values
						));
						
					}
					
				}
			}
			
		}
		
		Configuration::updateValue('COPERNICA_UPD', date('Y-m-d H:m:i'));
		
		return $errors;
		
	}
	
	
	private function _connect() {
		
		// Host überprüfen
		if($this->serverAvailable()) {
			
			try {
				
				// Verbindung herstellen, einloggen
				$this->_soapclient = new PomSoapClient(Configuration::get('COPERNICA_HOSTNAME'), Configuration::get('COPERNICA_USERNAME'), Configuration::get('COPERNICA_ACCOUNT'), Configuration::get('COPERNICA_PASSWORD'));
				
				// Verbindung fehlgeschlagen?
				if(!is_object($this->_soapclient) or ($soapclient = get_object_vars($this->_soapclient) and isset($soapclient['__soap_fault']))) {
					Logger::addLog($this->l('Copernica login informations are not valid and SOAP Fault!'), 3);
					$this->_soapclient = null;
					return false;
				}
				
			}
			catch(Exception $e) {
				Logger::addLog($this->l('Copernica login informations are not valid!'), 3);
				return false;
			}
			
		}
		else {
			Logger::addLog($this->l('Copernica server is not available!'), 3);
			$this->_soapclient = null;
			return false;
		}
		
		return true;
		
	}
	
	private function _databaseExists($name='') {
		
		if(empty($name))
			$name = Configuration::get('COPERNICA_DBNAME');
		
		try {
			
			$result = $this->_soapclient->Account_database(array(
				'identifier' => $name
			));
			
			return $result;
			
			return is_object($db) ? $db : false;
			
		}
		catch(Exception $e) {
			return false;
		}
		
    }
	
	private function _collectionExists($name) {
		
		$key = md5('Collection|'.$name);
		
		if(isset($this->_cache[$key]))
			return $this->_cache[$key];
		
		$db = $this->_databaseExists();
		
		try {
			
			$result = $this->_soapclient->Database_Collection(array(
				'identifier' => $name,
				'id' => $db->id
			));
			
			if(is_object($result)) {
				return $this->_cache[$key] = $result;
			}
			else {
				return false;
			}
			
		}
		catch(Exception $e) {
			return false;
		}
		
    }
	
	private function _fieldExists($name, $collection='') {
		
		$key = md5('Field|'.$collection.'|'.$name);
		
		if(isset($this->_cache[$key]))
			return $this->_cache[$key];
		
		$db = $this->_databaseExists();
		
		try {
			
			if(empty($collection)) {
				$result = $this->_soapclient->Database_Field(array(
					'identifier' => $name,
					'id' => $db->id
				));
			}
			else {
				$result = $this->_soapclient->Database_Collection(array(
					'identifier' => $name,
					'id' => $db->id
				));
			}
			
			if(is_object($result)) {
				return $this->_cache[$key] = $result;
			}
			else {
				unset($this->_cache[$key]);
				return false;
			}
			
		}
		catch(Exception $e) {
			var_dump($e);
			return false;
		}
		
    }
	
	private function _profileExists($id) {
		
		$key = md5('Profile|'.$id);
		
		if(isset($this->_cache[$key]))
			return $this->_cache[$key];
		
		try {
			
			$database = $this->_databaseExists();
			
			$fields = $this->_getFieldsFromDB('');
			$name = '';
			
			foreach($fields as $field) {
				if($field['field']=='id_customer') {
					$name = $field['name'];
					break;
				}
			}
			
			if(empty($name)) {
				unset($this->_cache[$key]);
				return false;
			}
			
			$result = $this->_soapclient->Database_searchProfiles(array(
				'id' => $database->id,
				'requirements' =>  array(
					$this->_soapclient->toObject(array(
						'fieldname'     =>  $name,
						'value'         =>  $id,
						'operator'      =>  '='
				)))
			));
			
			if(is_object($result)) {
				foreach($result->items as $profile) {
					return $this->_cache[$key] = $profile;
				}
			}
			else {
				return false;
			}
			
		}
		catch(Exception $e) {
			var_dump($e);
			return false;
		}
		
    }
	
	private function _subprofileExists($collection, $profile, $id) {
		
		$key = md5('Subprofile|'.$id.'|'.$profile->id);
		
		if(isset($this->_cache[$key]))
			return $this->_cache[$key];
		
		try {
			
			$fields = $this->_getFieldsFromDB($collection);
			$name = '';
			
			$collection = $this->_collectionExists($collection);
			
			foreach($fields as $field) {
				if($field['field']=='id_customer') {
					$name = $field['name'];
					break;
				}
			}
			
			if(empty($name)) {
				unset($this->_cache[$key]);
				return false;
			}
			
			$result = $this->_soapclient->Profile_searchSubProfiles(array(
				'id' => $profile->id,
				'collection' => $collection,
				'requirements' =>  array(
					$this->_soapclient->toObject(array(
						'fieldname'     =>  $name,
						'value'         =>  $id,
						'operator'      =>  '='
				)))
			));
			
			if(is_object($result)) {
				foreach($result->items as $subprofile) {
					return $this->_cache[$key] = $subprofile;
				}
			}
			else {
				return false;
			}
			
		}
		catch(Exception $e) {
			var_dump($e);
			return false;
		}
		
    }
	
	private function _createDatabase($name) {
		
		try{
			$result = $this->_soapclient->Account_createDatabase(array('name' => $name));
			return $result;
		}
		catch(Exception $e) {
			var_dump($e);
			return false;
		}
		
	}
	
	private function _createDatabaseField(&$db, $name, $field) {
			
		$values = array(
			'id'      => $db->id,
			'name'    => $name,
			'display' => true,
			'type'    => $field['type'],
			'length'  => ($field['type']=='text' ? $field['length'] : '')
		);
		
		try {
			return $this->_soapclient->Database_createField($values);
		}
		catch(Exception $e) {
			var_dump($e);
			return false;
		}
		
	}
	
	private function _createCollection(&$db, $name) {
		
		try{
			$result = $this->_soapclient->Database_createCollection(array(
				'id' =>  $db->id,
				'name' =>  $name
			));
			return $result;
		}
		catch(Exception $e) {
			var_dump($e);
			return false;
		}
		
	}
	
	private function _createCollectionField(&$collection, $name, $field) {
			
		$values = array(
			'id' =>  $collection->id,
			'name' =>  $name,
			'display' =>  true,
			'type'    => $field['type'],
			'length'  => ($field['type']=='text' ? $field['length'] : '')
		);
		
		try {
			$result = $this->_soapclient->Collection_createField($values);
			return $result;
		}
		catch(Exception $e) {
			var_dump($e);
			return false;
		}
		
	}
	
	private function _getFieldsFromDB($collection=false) {
		
		if($collection===false) $key = md5('DbFields');
		elseif(empty($collection)) $key = md5('DbFields0');
		else $key = md5('DbFields|'.$collection);
		
		if(isset($this->_cache[$key]))
			return $this->_cache[$key];
		
		if($collection===false)
			return $this->_cache[$key] = DB::getInstance()->ExecuteS("SELECT * FROM `"._DB_PREFIX_."copernica` ORDER BY collection, field");
		elseif(empty($collection))
			return $this->_cache[$key] = DB::getInstance()->ExecuteS("SELECT * FROM `"._DB_PREFIX_."copernica` WHERE collection=''");
		else
			return $this->_cache[$key] = DB::getInstance()->ExecuteS("SELECT * FROM `"._DB_PREFIX_."copernica` WHERE collection='".$collection."'");
		
	}
	
	private function _updateFieldsToDB($fields) {
		
		foreach($fields as $field)
			DB::getInstance()->ExecuteS("UPDATE `"._DB_PREFIX_."copernica` SET name='".$field['name']."', ready='".$field['ready']."' WHERE field='".$field['field']."' AND collection='".$field['collection']."'");
		
	}
	
	/*
	*	Admin integration
	*/
	
	private function _postProcess() {
		
		// Generelle Einstellungen speichern
		if (Tools::isSubmit('submitCopernicaSettings')) {
			
			$errors = array();
			
			// Hostname
			if(!$hostname = Tools::getValue('hostname') or empty($hostname))
				$errors[] = $this->l('The hostname is empty!');
			elseif(!Validate::isAbsoluteUrl($hostname))
				$errors[] = $this->l('The hostname \''.$hostname.'\' seems not to be right.');
			else 
				Configuration::updateValue('COPERNICA_HOSTNAME', $hostname);
			
			// Benutzer
			if(!$username = Tools::getValue('username') or empty($username))
				$errors[] = $this->l('The username is empty!');
			else
				Configuration::updateValue('COPERNICA_USERNAME', $username);
			
			// Account
			if(!$account = Tools::getValue('account') or empty($account))
				$errors[] = $this->l('The account name is empty!');
			else
				Configuration::updateValue('COPERNICA_ACCOUNT', $account);
			
			// Passwor
			if(!$password = Tools::getValue('password') or empty($password))
				$errors[] = $this->l('The password is empty!');
			elseif(!$this->isPasswd($password))
				$errors[] = $this->l('The password seems not to be right!');
			else
				Configuration::updateValue('COPERNICA_PASSWORD', $password);
			
			// Wenn keine Fehler: Versuche Verbindung aufzubauen
			if(count($errors) <= 0 and !$this->_connect()) {
				$errors[] = $this->l('Can\'t connect to the Copernica Server! Please check your login informations');
			}
			
			if(count($errors) > 0 )
				return $this->displayError('<ul><li>'.implode('</li><li>', $errors).'</li></ul>');
			else {
				Configuration::updateValue('COPERNICA_STEP1_COMPLETE', '1');
				Configuration::updateValue('COPERNICA_STEP2_COMPLETE', '0');
				Configuration::updateValue('COPERNICA_STEP3_COMPLETE', '0');
				return $this->displayConfirmation($this->l('General settings successfully updated and can connect to the copernica server!'));
			}
			
		}
		
		// Datenbankname
		if (Tools::isSubmit('submitCopernicaDB')) {
			
			$errors = array();
			
			// Versuche Verbindung zum Server aufzubauen
			if(!$this->_connect()) {
				$errors[] = $this->l('Your general configuration seems not to be right! Please check the values of step 1.');
			}
			elseif(!$dbname = Tools::getValue('dbname') or empty($dbname)) {
				$errors[] = $this->l('The database name is empty!');
			}
			elseif(!Validate::$this->isName($dbname)) {
				$errors[] = $this->l('The database name \''.$dbname.'\' seems not to be right!');
			}
			else {
				
				Configuration::updateValue('COPERNICA_DBNAME', $dbname);
				
				// Datenbank existiert bereits
				if($this->_databaseExists()) {
					Configuration::updateValue('COPERNICA_STEP2_COMPLETE', '1');
					Configuration::updateValue('COPERNICA_STEP3_COMPLETE', '1');
					DB::getInstance()->ExecuteS("UPDATE `"._DB_PREFIX_."copernica` SET ready='1'");
					return $this->displayConfirmation($this->l('The database \''.$dbname.'\' already exists! There is nothing wrong but be patient: existing data can be lost!'));
				}
				// Datenbank erstellen
				elseif($this->_createDatabase($dbname)) {
					Configuration::updateValue('COPERNICA_STEP2_COMPLETE', '1');
					DB::getInstance()->ExecuteS("UPDATE `"._DB_PREFIX_."copernica` SET ready='0'");
					return $this->displayConfirmation($this->l('The database \''.$dbname.'\' was successfull created'));
				}
				else
					$errors[] = $this->l('Can\'t create database \''.$dbname.'\'');
				
			}
			
			if(count($errors) > 0)
				return $this->displayError('<ul><li>'.implode('</li><li>', $errors).'</li></ul>');
			else {
				return $this->displayConfirmation($this->l('Database settings successfully updated!'));
			}
			
		}
		
		// Datenbankfelder einfügen
		if(Tools::isSubmit('submitCopernicaFields')) {
			
			$errors = array();
			
			// Alle Datenbankfelder und Einstellungen aus der lokalen Datenbank holen
			$fields = $this->_getFieldsFromDB();
			
			// Versuche Verbindung zum Server aufzubauen
			if(!$this->_connect()) {
				$errors[] = $this->l('Your general configuration seems not to be right! Please check the values of step 1.');
			}
			// Prüfung ob datenbank existiert
			elseif(!$db = $this->_databaseExists()) {
				$errors[] = $this->l('The Database doesn\'t exist!');
			}
			else {
				
				$ready = true;
				
				// Alle Datenbankfelder durchgehen
				foreach($fields as $key => $field) {
					
					$error = array();
					
					// Wenn das Feld bereits in Copernica existiert
					if(empty($field['collection']) and $field_new = $this->_fieldExists(Tools::getValue('field_'.$field['field']))) {
						
						$fields[$key]['name'] = $field_new->name;
						$fields[$key]['ready'] = 1;
						
					}
					elseif($collection_new = $this->_fieldExists(Tools::getValue('field_'.$field['collection'].'_'.$field['field'], $field['collection']))) {
						
						$fields[$key]['name'] = $collection_new->name;
						$fields[$key]['ready'] = 1;
						
					}
					
					// Wenn Feld nicht zu einer Collection gehört ist es ein Profilfeld
					elseif(empty($field['collection']) and !$this->_createDatabaseField($db, Tools::getValue('field_'.$field['field']), $field)) {
						
						$error[] = $this->l('Can\'t create Profile Field \''.Tools::getValue('field_'.$field['field']).'\' ('.$field['field'].')');
						$fields[$key]['ready'] = 0;
						
					}
					
					// Wenn es zu einer Collection gehört und diese schon existiert, wird das Feld angelegt
					elseif($collection = $this->_collectionExists($field['collection']) and !$this->_createCollectionField($collection, Tools::getValue('field_'.$field['collection'].'_'.$field['field']), $field)) {
						
						$error[] = $this->l('Can\'t create Collection Field \''.Tools::getValue('field_'.$field['collection'].'_'.$field['field']).'\'');
						$fields[$key]['ready'] = 0;
						
					}
					
					// Wenn es zu einer Collection gehört, diese aber noch nicht existiert, wird zuerst die Collection und dann das Datenbankfeld angelegt
					elseif($collection = $this->_createCollection($db, $field['collection']) and !$this->_createCollectionField($collection, Tools::getValue('field_'.$field['collection'].'_'.$field['field']), $field)) {
						
						$error[] = $this->l('Can\'t create Collection \''.$field['collection'].'\' or Collection Field \''.Tools::getValue('field_'.$field['collection'].'_'.$field['field']).'\'');
						$fields[$key]['ready'] = 0;
						
					}
					
					// Keine Fehler vorhanden? Feld wird in DB aktualisiert
					if(count($error) <= 0) {
						
						if(empty($field['collection']))
							$fields[$key]['name'] = Tools::getValue('field_'.$field['field']);
						else
							$fields[$key]['name'] = Tools::getValue('field_'.$field['collection'].'_'.$field['field']);
						
						$fields[$key]['ready'] = 1;
						
					}
					else {
						$errors = array_merge($errors, $error);
						$ready = false;
					}
					
				}
				
				if($ready == true)
					Configuration::updateValue('COPERNICA_STEP3_COMPLETE', '1');
				
				$this->_updateFieldsToDB($fields);
				
			}
			
			if(count($errors) > 0)
				return $this->displayError('<ul><li>'.implode('</li><li>', $errors).'</li></ul>');
			else {
				return $this->displayConfirmation($this->l('Fields are successfully updated!'));
			}
			
		}
		
		// Sync starten
		if(Tools::isSubmit('submitCopernicaSync')) {
			
			$errors = $this->_executeSync();
			
			if(count($errors) > 0)
				return $this->displayError('<ul><li>'.implode('</li><li>', $errors).'</li></ul>');
			else
				return $this->displayConfirmation($this->l('Sync successfully executed!'));
			
		}
		
		
	}
	
	private function _displayForm() {
		
		$html = '
			<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
				<fieldset class="width2">
					<legend>'.$this->l('Step 1: General Settings').'</legend>
					<p>'.$this->l('Please enter here the login informations you got from Copernica.').'</p>
					<label>'.$this->l('Hostname').'</label>
					<div class="margin-form">
						<input type="text" name="hostname" value="'.Tools::getValue('hostname', Configuration::get('COPERNICA_HOSTNAME')).'" />
						<p class="clear">'.$this->l('The Url to the Copernica Server').'</p>
					</div>
					<label>'.$this->l('Username').'</label>
					<div class="margin-form">
						<input type="text" name="username" value="'.Tools::getValue('username', Configuration::get('COPERNICA_USERNAME')).'" />
						<p class="clear">'.$this->l('Your Copernica username').'</p>
					</div>
					<label>'.$this->l('Account').'</label>
					<div class="margin-form">
						<input type="text" name="account" value="'.Tools::getValue('account', Configuration::get('COPERNICA_ACCOUNT')).'" />
						<p class="clear">'.$this->l('The accountname at your Copernica server').'</p>
					</div>
					<label>'.$this->l('Password').'</label>
					<div class="margin-form">
						<input type="password" name="password" value="'.Tools::getValue('password', Configuration::get('COPERNICA_PASSWORD')).'" />
						<p class="clear">'.$this->l('The Password').'</p>
					</div>
					<center><input type="submit" name="submitCopernicaSettings" value="'.$this->l('Update').'" class="button" /></center>
				</fieldset>
			</form>
			
			<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
				<fieldset class="width2">
					<legend>'.$this->l('Step 2: Name your Database').'</legend>
					<p>'.$this->l('Choose a name for your database.').'</p>
					<label>'.$this->l('Database Name').'</label>
					<div class="margin-form">
						<input type="text" name="dbname" value="'.Tools::getValue('dbname', Configuration::get('COPERNICA_DBNAME')).'" '.(Configuration::get('COPERNICA_STEP1_COMPLETE')!='1' ? 'disabled="disabled" ' : '').'/>
						<p class="clear">'.$this->l('If this name already exists a new database won\'t be created').'</p>
					</div>
					<center><input type="submit" name="submitCopernicaDB" value="'.$this->l('Create Database').'" class="button" '.((Configuration::get('COPERNICA_STEP1_COMPLETE')!='1' or Configuration::get('COPERNICA_STEP2_COMPLETE')=='1') ? 'disabled="disabled" ' : '').'/></center>
				</fieldset>
			</form>
		';
		
		
		
		$html .= '
			<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
				<fieldset class="width2">
					<legend>'.$this->l('Step 3: Configure your Fields').'</legend>
		';
		
		$collections = array('', 'Address', 'Orders', 'OrderProducts', 'Cart', 'CartProducts');
		
		foreach($collections as $collection) {
			
			$fields = $this->_getFieldsFromDB($collection);
			
			if($collection == '') $label = $this->l('Profile');
			else $label = $this->l('SubProfile').' '.$collection;
				
			$html .= '<fieldset><legend>'.$label.'</legend>';
			
			foreach($fields as $field) {
				
				if(empty($field['collection'])) {
					$html .= '
						<label>'.$field['field'].'</label>
						<div class="margin-form">
							<input type="text" name="field_'.$field['field'].'" value="'.Tools::getValue('field_'.$field['field'], $field['name']).'" '.($field['ready']=='1' ? 'disabled="disabled" ' : '').'/>
						</div>
					';
				}
				else {
					$html .= '
						<label>'.$field['field'].'</label>
						<div class="margin-form">
							<input type="text" name="field_'.$field['collection'].'_'.$field['field'].'" value="'.Tools::getValue('field_'.$field['collection'].'_'.$field['field'], $field['name']).'" '.($field['ready']=='1' ? 'disabled="disabled" ' : '').'/>
						</div>
					';

				}
			}
			
			$html .= '</fieldset>';
			
		}
		
		$html .= '
					<center><input type="submit" name="submitCopernicaFields" value="'.$this->l('Save Settings').'" class="button" '.((Configuration::get('COPERNICA_STEP2_COMPLETE')!='1' or Configuration::get('COPERNICA_STEP3_COMPLETE')=='1') ? 'disabled="disabled" ' : '').'/></center>
				</fieldset>
			</form>
		';
		
		$html .= '
			<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
				<fieldset class="width2">
					<legend>'.$this->l('Step 4: Sync to Copernica').'</legend>
					<p>'.$this->l('Press this Button every time you want to sync your data to the Copernica Server').'</p>
					<input type="submit" name="submitCopernicaSync" value="'.$this->l('Sync now!').'" class="button" '.(Configuration::get('COPERNICA_STEP3_COMPLETE')!='1' ? 'disabled="disabled" ' : '').'/>
				</fieldset>
			</form>
		';
		
		return $html;
		
	}
	
	public function getContent() {
		
		$html = '<h2>'.$this->displayName.'</h2>';
		
		if(!empty($this->warning))
			$html .= $this->displayWarning($this->warning);
		
		$html .= $this->_postProcess();
		$html .= $this->_displayForm();
		
		return $html;
		
	}
	
	public function isPasswd($passwd, $size = 5) {
		return preg_match('/^[.a-zA-Z_0-9-!@#$%\^&*()]{'.(int)$size.',32}$/', $passwd);
	}
	
	public static function isName($name) {
		return preg_match('/^[^!<>,;?=+()@#"°{}_$%:]*$/u', stripslashes($name));
	}
	
	public function displayWarning($warning) {
	 	$output = '
		<div class="warn">
			<img src="'._PS_IMG_.'admin/warn2.png" alt="" title="" /> '.$warning.'
		</div>';
		return $output;
	}
	
}
