(function ($) {
  Drupal.behaviors.copernica_webform = {
    attach: function (context, settings) {
      $('fieldset#edit-copernica-webform', context).once('copernica-webform', function() {
        $(this).drupalSetSummary(function (context) {
          var integration_type = $(':input[name="copernica_webform_enabled"]:checked', context).val();
          switch (integration_type) {
            case 'integrate_off':
              return Drupal.t('Disabled');

            case 'integrate_existing':
              var collection = $(':input[name="copernica_webform_collection"] :selected', context).text();
              return Drupal.t('Using: @collection', { '@collection' : collection });

            case 'integrate_new':
              var collection = $(':input[name="copernica_webform_collection_new"]', context).val();
              return Drupal.t('Creating: @collection', { '@collection' : collection });
          }

          return '';
        });
      });
    }
  };
})(jQuery);
