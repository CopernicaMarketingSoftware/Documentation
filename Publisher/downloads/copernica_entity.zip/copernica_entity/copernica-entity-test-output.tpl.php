<div class="copernica-entity-test-data-wrapper">
  <?php
    $items = array();
    foreach ($output['store_fields'] as $copernica_field => $value) {
      $items[] = '<strong>' . check_plain($copernica_field) . '</strong>: ' . check_plain($value);
    }
    print theme('item_list', array('items' => $items, 'title' => t('Data being stored')));
  ?>
  <hr class="copernica-entity-test-data-separator" />
  <?php
    $items = array();
    foreach ($output['key_fields'] as $copernica_field => $value) {
      $items[] = '<strong>' . check_plain($copernica_field) . '</strong>: ' . check_plain($value);
    }
    $collection = $mapping->collection;
    $title = empty($collection) ? 'Profile matchings' : 'Subprofile matchings';
    print theme('item_list', array('items' => $items, 'title' => t($title)));
  ?>
  <?php if (!empty($collection)): ?>
  <hr class="copernica-entity-test-data-separator" />
  <?php
    $items = array();
    foreach ($output['profile_key_fields'] as $copernica_field => $value) {
      $items[] = '<strong>' . check_plain($copernica_field) . '</strong>: ' . check_plain($value);
    }
    print theme('item_list', array('items' => $items, 'title' => t('Profile matchings')));
  ?>
  <?php endif; ?>
</div>