<?php
/**
* @version 1.3.0
* @package RSform!Pro 1.3.0
* @copyright (C) 2012 www.comrads.nl
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die('Restricted access');

class TableRSForm_Copernica extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $form_id = null;
	var $co_form_active = 0;
	var $co_form_list_id = '';
	var $co_form_credentials = 1; 
	var $co_form_username = '';
	var $co_form_accountname = '';
	var $co_form_password = '';
	var $co_merge_vars = '';
	var $co_merge_vars_update = '';
	var $co_merge_vars_ignore = '';
	var $co_merge_vars_key = '';
		
	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableRSForm_Copernica(& $db)
	{
		parent::__construct('#__rsform_copernica', 'form_id', $db);
	}
}