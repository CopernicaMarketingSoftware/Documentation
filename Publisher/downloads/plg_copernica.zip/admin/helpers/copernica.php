<?php
/**
 * @version 1.3.0
 * @package RSform!Pro 1.3.0
 * @copyright (C) 2012 www.comrads.nl - Peter Ruiter
 * @license GPL, http://www.gnu.org/copyleft/gpl.html
 */
defined('_JEXEC') or die('Restricted access');
?>
<style>ul.rsform_leftnav li a#copernica span {
	background: url(components/com_rsform/assets/images/icons/copernica.png) no-repeat 10px center;
}</style>
<script type="text/javascript">
    function rsfp_changeCoDatabases(what)
    {
        var savedMergeValues = new Array();
        <?php 
        foreach ($merge_vars as $k=>$v) {                
            echo "savedMergeValues[".$k."] = '".addslashes($v)."';\n";
        }  
        ?>
        
        var savedMergeUpdateValues = new Array();
        <?php 
        foreach ($merge_vars_update as $k=>$v) {                
            echo "savedMergeUpdateValues[".$k."] = '".addslashes($v)."';\n";
        }  
        ?>
                
        var savedMergeKeys = new Array();
        <?php 
        foreach ($merge_vars_key as $k=>$v) {                
            echo "savedMergeKeys[".$k."] = '".addslashes($v)."';\n";
        }  
        ?>
                
        var savedMergeIgnoreValues = new Array();
        <?php 
        foreach ($merge_vars_ignore as $k=>$v) {                
            echo "savedMergeIgnoreValues[".$k."] = '".addslashes($v)."';\n";
        }  
        ?>
        
        var value = what;        
	
        document.getElementById('co_state').innerHTML='Status: loading...';
        document.getElementById('co_state').style.color='rgb(255,0,0)';
	
        var params = new Array();
        params.push('list_id=' + escape(value));
	
        xml = buildXmlHttp();
        var url = 'index.php?option=com_rsform&task=plugin&co_plugin_task=get_merge_vars';
        xml.open("POST", url, true);
	
        params = params.join('&');
	
        //Send the proper header information along with the request
        xml.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xml.setRequestHeader("Content-length", params.length);
        xml.setRequestHeader("Connection", "close");
	
        xml.send(params);
        xml.onreadystatechange=function()
        {
            if (xml.readyState==4)
            {
                var table = document.getElementById('co_merge_vars');
                while (table.rows.length >= 1)
                    table.deleteRow(table.rows.length - 1);
		
                var result = xml.responseText.split("\n");
                for (var i=0; i<(result.length-1); i+=2)
                {
                    var x = table.insertRow(table.rows.length);
				
                    var y = x.insertCell(0);
                    var select = document.createElement('select');
                    select.name = 'co_merge_vars[' + result[i] + ']';
                    select.id = 'co_merge_vars[' + result[i] + ']';
<?php foreach ($fields_array as $field) { ?>
                        var option = document.createElement('option');
                        option.text = option.value = '<?php echo $field; ?>';
                        if (savedMergeValues[result[i]] == '<?php echo $field; ?>') {
                            option.setAttribute("selected","selected");
                        }
                        select.options.add(option);
<?php } ?>
                    y.appendChild(select);
                    y.align = 'right';
                                
                    var y = x.insertCell(1);
                    y.innerHTML = '' + result[i+1];
                    y.nowrap = true;
                    y.align = 'left';

                    var y = x.insertCell(2);
                    var checkbox = document.createElement('input');
                    checkbox.type = 'checkbox';
                    checkbox.name = 'co_merge_vars_key[' + result[i] + ']';
                    checkbox.value = '1';
                    checkbox.id = 'co_merge_vars_key[' + result[i] + ']';
                    if (savedMergeKeys[result[i]] == '1') {
                        checkbox.setAttribute("checked","checked");
                    }                                
                    y.appendChild(checkbox);                                
                    y.nowrap = true;
                    y.align = 'left';
                    
                    var y = x.insertCell(3);
                    var checkbox = document.createElement('input');
                    checkbox.type = 'checkbox';
                    checkbox.name = 'co_merge_vars_ignore[' + result[i] + ']';
                    checkbox.value = '1';
                    checkbox.id = 'co_merge_vars_ignore[' + result[i] + ']';
                    if (savedMergeIgnoreValues[result[i]] == '1') {
                        checkbox.setAttribute("checked","checked");
                    }                                
                    checkbox.setAttribute("onclick","rsfp_checkUpdateCheckboxes('ignore',"+result[i]+");");
                    y.appendChild(checkbox);                                
                    y.nowrap = true;
                    y.align = 'left';
                    
                    var y = x.insertCell(4);
                    var checkbox = document.createElement('input');
                    checkbox.type = 'checkbox';
                    checkbox.name = 'co_merge_vars_update[' + result[i] + ']';
                    checkbox.value = '1';
                    checkbox.id = 'co_merge_vars_update[' + result[i] + ']';
                    if (savedMergeUpdateValues[result[i]] == '1') {
                        checkbox.setAttribute("checked","checked");
                    }
                    checkbox.setAttribute("onclick","rsfp_checkUpdateCheckboxes('update',"+result[i]+");");
                    y.appendChild(checkbox);                                
                    y.nowrap = true;
                    y.align = 'left';                    
                    
                }
				
                document.getElementById('co_state').innerHTML='Status: ok';
                document.getElementById('co_state').style.color='';
                rsfp_changeCoMapping();
            }        
        }        
        
    }
    
    function rsfp_checkUpdateCheckboxes(kind, fieldId) {        
        if (kind == 'update') {
            jQuery('#co_merge_vars_ignore\\['+fieldId+'\\]').attr('checked', false);
        }
        if (kind == 'ignore') {
            jQuery('#co_merge_vars_update\\['+fieldId+'\\]').attr('checked', false);
        }        
    }

    function rsfp_changeCoCredentials() {
        if (jQuery('input:radio[name=co_form_credentials]:checked').val() == 1) {
            jQuery('.co_default-credentials').hide();
        } else {
            jQuery('.co_default-credentials').show();
        }  
        if (jQuery('input:radio[name=co_form_active]:checked').val() != 1) {
            jQuery('.co_default-credentials').hide();
        }
    }
    
    function rsfp_changeCoMapping() {
        if (jQuery('#co_form_list_id').val() != 0 && jQuery('#co_form_list_id').val() != '' && jQuery('#co_form_list_id').val() != null) {        
            jQuery('.co_mapping').show();
        } else {
            jQuery('.co_mapping').hide();
        }    
        
        if (jQuery('input:radio[name=co_form_active]:checked').val() != 1) {
            jQuery('.co_mapping').hide();
        }
    }
    
    function rsfp_changeCoActive() {
        if (jQuery('input:radio[name=co_form_active]:checked').val() == 1) {
            jQuery('.co_default-credentials').show();
            jQuery('.co_credentials').show();
            jQuery('.co_databases').show();
            jQuery('.co_mapping').show();
            jQuery('.co_status').show();            
                        
            rsfp_changeCoCredentials();
            if (jQuery('#co_form_list_id').val() != 0 && jQuery('#co_form_list_id').val() != '' && jQuery('#co_form_list_id').val() != null) {        
                rsfp_changeCoDatabases(jQuery('#co_form_list_id').val());
            }
            
        } else {           
            jQuery('.co_default-credentials').hide();
            jQuery('.co_credentials').hide();
            jQuery('.co_databases').hide();
            jQuery('.co_mapping').hide();
            jQuery('.co_status').hide();
        }    
    }

    jQuery(document).ready(function() {
        // Set initial view for default fields
        rsfp_changeCoActive();
        rsfp_changeCoCredentials();
  
        if (jQuery('#co_form_list_id').val() != 0 && jQuery('#co_form_list_id').val() != '' && jQuery('#co_form_list_id').val() != null) {        
            rsfp_changeCoDatabases(jQuery('#co_form_list_id').val());
        }
        rsfp_changeCoMapping();        
    });
</script>

<table class="admintable">
    <tr>
        <td valign="top" align="left" width="30%">
            <table>
                <tr>
                    <td colspan="5"><?php echo JHTML::image('administrator/components/com_rsform/assets/images/copernica.jpg', 'Copernica'); ?></td>
                </tr>
                <tr>
                    <td colspan="5"><div class="rsform_error" style="text-align:left;"><?php echo JText::_('RSFP_COPERNICA_DESC'); ?></div></td>
                </tr>
                <tr>
                    <td colspan="5">&nbsp;</td>                   
                </tr>  

                <tr class="co_integration">
                    <td colspan="5" class="key" align="center"><p align="center"><?php echo JText::_('RSFP_COPERNICA_INTEGRATION'); ?></p></td>
                </tr>
                <tr class="co_integration">
                    <td width="80" align="right" nowrap="nowrap" class="key">
                        <span class="hasTip" title="<?php echo JText::_('RSFP_COPERNICA_INTEGRATION_DESC'); ?>"><?php echo JText::_('RSFP_COPERNICA_INTEGRATION'); ?></span>
                    </td>
                    <td colspan="4"><?php echo $lists['co_form_active']; ?></td>
                </tr>        
                <tr>
                    <td colspan="5">&nbsp;</td>                   
                </tr> 

                <tr class="co_credentials">
                    <td colspan="5" class="key" align="center"><p align="center"><?php echo JText::_('RSFP_COPERNICA_CREDENTIALS'); ?></p></td>
                </tr>
                <tr class="co_credentials">
                    <td width="80" align="right" nowrap="nowrap" class="key"><?php echo JText::_('RSFP_COPERNICA_USE_DEFAULT_CREDENTIALS'); ?></td>
                    <td colspan="4"><?php echo $lists['co_form_credentials']; ?></td>
                </tr>                        
                <tr class="co_credentials co_default-credentials" style="display:none">
                    <td width="80" align="right" nowrap="nowrap" class="key">
                        <span class="hasTip" title="<?php echo JText::_('RSFP_COPERNICA_API_ACCOUNTNAME_DESC'); ?>"><?php echo JText::_('RSFP_COPERNICA_API_ACCOUNTNAME'); ?></span>
                    </td>
                    <td colspan="4" nowrap="nowrap"><input type="text" name="co_form_accountname" size="50" maxlength="255" value="<?php echo $row->co_form_accountname ?>" /></td>
                </tr>
                <tr class="co_credentials co_default-credentials" style="display:none">
                    <td width="80" align="right" nowrap="nowrap" class="key">
                        <span class="hasTip" title="<?php echo JText::_('RSFP_COPERNICA_API_USERNAME_DESC'); ?>"><?php echo JText::_('RSFP_COPERNICA_API_USERNAME'); ?></span>
                    </td>
                    <td colspan="4" nowrap="nowrap"><input type="text" name="co_form_username" size="50" maxlength="255" value="<?php echo $row->co_form_username ?>" /></td>
                </tr>
                <tr class="co_credentials co_default-credentials" style="display:none">
                    <td width="80" align="right" nowrap="nowrap" class="key">
                        <span class="hasTip" title="<?php echo JText::_('RSFP_COPERNICA_API_PASSWORD_DESC'); ?>"><?php echo JText::_('RSFP_COPERNICA_API_PASSWORD'); ?></span>
                    </td>
                    <td colspan="4" nowrap="nowrap"><input type="password" name="co_form_password" size="50" maxlength="255" value="<?php echo $row->co_form_password ?>" /></td>
                </tr>
                <tr>
                    <td colspan="5">&nbsp;</td>                   
                </tr>  



                <tr class="co_databases">
                    <td colspan="5" class="key" align="center"><p align="center"><?php echo JText::_('RSFP_COPERNICA_API_DATABASES'); ?></p></td>
                </tr>
                <tr class="co_databases">
                    <td width="80" align="right" nowrap="nowrap" class="key">
                        <span class="hasTip" title="<?php echo JText::_('RSFP_COPERNICA_API_DATABASE_DESC'); ?>"><?php echo JText::_('RSFP_COPERNICA_API_DATABASES'); ?></span>
                    </td>
                    <td colspan="4" nowrap="nowrap"><?php echo $lists['co_databases']; ?></td>
                </tr>
                <tr>
                    <td colspan="5">&nbsp;</td>                   
                </tr>  



                <tr class="co_mapping">
                    <td colspan="5" class="key" align="center"><p align="center"><?php echo JText::_('RSFP_COPERNICA_API_MAPPING'); ?></p></td>
                </tr>
                <tr class="co_mapping">
                    <td colspan="5"><?php echo JText::_('RSFP_COPERNICA_MERGE_VARS_DESC'); ?></td>
                </tr>
                 <tr class="co_mapping">
                    <td colspan="5"><div class="rsform_error" style="text-align:left;"><?php echo JText::_('RSFP_COPERNICA_MERGE_VARS_TABLE_HEADING_ADD_TO_EXISTING_DESC'); ?></div></td>
                </tr>
                <tr class="co_mapping">
                    <td align="right"><strong><?php echo JText::_('RSFP_COPERNICA_MERGE_VARS_TABLE_HEADING_RSFORM_FIELD'); ?></strong></td>
                    <td align="left"><strong><?php echo JText::_('RSFP_COPERNICA_MERGE_VARS_TABLE_HEADING_COPERNICA_FIELD'); ?></strong></td>
                    <td align="left"><strong><?php echo JText::_('RSFP_COPERNICA_MERGE_VARS_TABLE_HEADING_KEY'); ?></strong></td>
                    <td align="left"><strong><?php echo JText::_('RSFP_COPERNICA_MERGE_VARS_TABLE_HEADING_IGNORE_IF_EXISTS'); ?></strong></td>
                    <td align="left"><strong><?php echo JText::_('RSFP_COPERNICA_MERGE_VARS_TABLE_HEADING_ADD_TO_EXISTING'); ?></strong></td>
                </tr>
                <tbody id="co_merge_vars" class="co_mapping">

                </tbody>
            
                <tr>
                    <td colspan="5">&nbsp;</td>                   
                </tr>                
                <tr>
                    <td colspan="5">&nbsp;</td>                   
                </tr>                
                <tr class="co_status">
                    <td width="80" align="right" nowrap="nowrap" class="key"><?php echo JText::_('RSFP_COPERNICA_CONNECTION_STATE'); ?></td>
                    <td colspan="4" id="co_state"></td>
                </tr>                
            </table>
        </td>
        <td valign="top">
            &nbsp;
        </td>
    </tr>
</table>