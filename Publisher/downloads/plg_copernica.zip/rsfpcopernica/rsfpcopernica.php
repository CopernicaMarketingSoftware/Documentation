<?php
/**
 * @version 1.0
 * @copyright (C) 2012 www.comrads.nl
 * @license GPL, http://www.gnu.org/copyleft/gpl.html
 */
// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

/**
 * RSForm! Pro system plugin
 */
class plgSystemRSFPCopernica extends JPlugin {

    /**
     * Constructor
     *
     * For php4 compatibility we must not use the __constructor as a constructor for plugins
     * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
     * This causes problems with cross-referencing necessary for the observer design pattern.
     *
     * @access	protected
     * @param	object	$subject The object to observe
     * @param 	array   $config  An array that holds the plugin configuration
     * @since	1.0
     */
    function plgSystemRSFPCopernica(&$subject, $config) {
        parent::__construct($subject, $config);
    }

    function canRun() {
        if (class_exists('RSFormProHelper')) {
            return true;
        }

        $helper = JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_rsform' . DS . 'helpers' . DS . 'rsform.php';
        if (file_exists($helper)) {
            require_once($helper);
            RSFormProHelper::readConfig();
            return true;
        }

        return false;
    }

    function rsfp_onFormSave($form) {
        $post = JRequest::get('post', JREQUEST_ALLOWRAW);
        $post['form_id'] = $post['formId'];

        //print_r($post);exit;

        $row = JTable::getInstance('RSForm_Copernica', 'Table');
        if (!$row) {
            return;
        }
        if (!$row->bind($post)) {
            JError::raiseWarning(500, $row->getError());
            return false;
        }

        $row->co_merge_vars = serialize($post['co_merge_vars']);
        $row->co_merge_vars_update = serialize($post['co_merge_vars_update']);
        $row->co_merge_vars_ignore = serialize($post['co_merge_vars_ignore']);
        $row->co_merge_vars_key = serialize($post['co_merge_vars_key']);

        $db = JFactory::getDBO();
        $db->setQuery("SELECT form_id FROM #__rsform_copernica WHERE form_id='" . (int) $post['form_id'] . "'");
        if (!$db->loadResult()) {
            $db->setQuery("INSERT INTO #__rsform_copernica SET form_id='" . (int) $post['form_id'] . "'");
            $db->query();
        }

        if ($row->store()) {
            return true;
        } else {
            JError::raiseWarning(500, $row->getError());
            return false;
        }
    }

    function rsfp_bk_onAfterShowFormEditTabs() {
        $formId = JRequest::getInt('formId');

        $lang = & JFactory::getLanguage();
        $lang->load('plg_system_rsfpcopernica');

        $row = JTable::getInstance('RSForm_Copernica', 'Table');
        if (!$row) {
            return;
        }
        $row->load($formId);

        $row->co_merge_vars = @unserialize($row->co_merge_vars);
        if ($row->co_merge_vars === false) {
            $row->co_merge_vars = array();
        }

        $row->co_merge_vars_update = @unserialize($row->co_merge_vars_update);
        if ($row->co_merge_vars_update === false) {
            $row->co_merge_vars_update = array();
        }

        $row->co_merge_vars_ignore = @unserialize($row->co_merge_vars_ignore);
        if ($row->co_merge_vars_ignore === false) {
            $row->co_merge_vars_ignore = array();
        }

        $row->co_merge_vars_key = @unserialize($row->co_merge_vars_key);
        if ($row->co_merge_vars_key === false) {
            $row->co_merge_vars_key = array();
        }

        if (RSFormProHelper::getConfig('copernica.api_accountname') == '') {
            JError::raiseWarning(500, '(Copernica) ' . 'You have to enter a default Copernica accountname in the RSForm configuration screen');
        }
        if (RSFormProHelper::getConfig('copernica.api_username') == '') {
            JError::raiseWarning(500, '(Copernica) ' . 'You have to enter a default Copernica username in the RSForm configuration screen');
        }
        if (RSFormProHelper::getConfig('copernica.api_password') == '') {
            JError::raiseWarning(500, '(Copernica) ' . 'You have to enter a default Copernica password in the RSForm configuration screen');
        }

        if ((int) $row->co_form_credentials == 1) {
            $copernica_account = RSFormProHelper::getConfig('copernica.api_accountname');
            $copernica_username = RSFormProHelper::getConfig('copernica.api_username');
            $copernica_password = RSFormProHelper::getConfig('copernica.api_password');
        } else {
            $copernica_account = $row->co_form_accountname;
            $copernica_username = $row->co_form_username;
            $copernica_password = $row->co_form_password;
        }

        $copernicaApi = '';
        $copernicaApiConnected = 0;
        if ((int) $row->co_form_credentials == 1 && ($copernica_account == '' || $copernica_username == '' || $copernica_password == '')) {
            JError::raiseWarning(500, '(Copernica) ' . JText::_('RSFP_COPERNICA_API_MISSING_CREDENTIALS'));
        } else {
            require_once(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_rsform' . DS . 'helpers' . DS . 'copernica_soapclient.php');

            try {
                $copernicaApi = new PomSoapClient("http://publisher.copernica.nl/", $copernica_username, $copernica_account, $copernica_password);
                $copernicaApiConnected = 1;
            } catch (Exception $e) {
                JError::raiseWarning(500, '(Copernica) ' . JText::_('RSFP_COPERNICA_API_BAD_CREDENTIALS'));
                $copernicaApiConnected = 0;
            }
        }

        jimport('joomla.html.pane');
        $tabs = & JPane::getInstance('Tabs', array(), true);

        // Get all RS Form! Fields
        $fields_array = $this->_getFields($formId);

        $fields = array();
        foreach ($fields_array as $field) {
            $fields[] = JHTML::_('select.option', $field, $field);
        }


        // Radio for choosing wheter or not to use the integration
        $lists['co_form_active'] = JHTML::_('select.booleanlist', 'co_form_active', 'class="inputbox" onclick="rsfp_changeCoActive();"', $row->co_form_active);

        // Radio for choosing wheter or not to use the default credentials
        $lists['co_form_credentials'] = JHTML::_('select.booleanlist', 'co_form_credentials', 'class="inputbox" onclick="rsfp_changeCoCredentials();"', $row->co_form_credentials);

        // Get All databases from Copernica
        if ($copernicaApiConnected) {
            $oCopernicaDatabases = $copernicaApi->Account_databases();
        } else {
            $oCopernicaDatabases = new stdClass();
            $oCopernicaDatabases->items = 0;
        }

        $aCopernicaDatabases = array();
        $aCopernicaDatabaseOptions = array();
        if (count($oCopernicaDatabases->items) > 0) {
            foreach ($oCopernicaDatabases->items as $oCopernicaDatabase) {
                $aCopernicaDatabases[$oCopernicaDatabase->id] = $oCopernicaDatabase->name;
            }
            foreach ($aCopernicaDatabases as $k => $v) {
                $aCopernicaDatabaseOptions[] = JHTML::_('select.option', $k, $v);
            }
        } else {
            $aCopernicaDatabaseOptions[] = JHTML::_('select.option', 0, RSFP_COPERNICA_API_NO_DATABASES);
        }

        $lists['co_databases'] = JHTML::_('select.genericlist', $aCopernicaDatabaseOptions, 'co_form_list_id', 'onchange="rsfp_changeCoDatabases(this.value);"', 'value', 'text', $row->co_form_list_id);

        // Merge Vars
        $merge_vars = $row->co_merge_vars;
        $merge_vars_update = $row->co_merge_vars_update;
        $merge_vars_ignore = $row->co_merge_vars_ignore;
        $merge_vars_key = $row->co_merge_vars_key;

        $lists['fields'] = array();
        if (is_array($merge_vars)) {
            foreach ($merge_vars as $i => $merge_var) {
                $lists['fields'][$merge_var[$i]] = JHTML::_('select.genericlist', $fields, 'co_merge_vars[' . $i . ']', null, 'value', 'text', isset($row->co_merge_vars[$i]) ? $row->co_merge_vars[$i] : null);
            }
        }

        echo '<div id="copernicadiv">';
        include(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_rsform' . DS . 'helpers' . DS . 'copernica.php');
        echo '</div>';
    }

    function rsfp_bk_onAfterShowFormEditTabsTab() {
        $lang = & JFactory::getLanguage();
        $lang->load('plg_system_rsfpcopernica');

        echo '<li><a href="javascript: void(0);" id="copernica"><span>' . JText::_('RSFP_COPERNICA_INTEGRATION') . '</span></a></li>';
    }

    function rsfp_f_onAfterFormProcess($args) {
        $db = JFactory::getDBO();

        $formId = (int) $args['formId'];
        $SubmissionId = (int) $args['SubmissionId'];

        $db->setQuery("SELECT * FROM #__rsform_copernica WHERE `form_id`='" . $formId . "' AND `co_form_active`='1'");
        if ($row = $db->loadObject()) {
            if (!$row->co_form_list_id) {
                return;
            }

            if ((int) $row->co_form_credentials == 1) {
                $copernica_account = RSFormProHelper::getConfig('copernica.api_accountname');
                $copernica_username = RSFormProHelper::getConfig('copernica.api_username');
                $copernica_password = RSFormProHelper::getConfig('copernica.api_password');
            } else {
                $copernica_account = $row->co_form_accountname;
                $copernica_username = $row->co_form_username;
                $copernica_password = $row->co_form_password;
            }

            $copernicaApi = '';
            $copernicaApiConnected = 0;
            if ((int) $row->co_form_credentials == 1 && ($copernica_account == '' || $copernica_username == '' || $copernica_password == '')) {
                JError::raiseWarning(500, '(Copernica) ' . JText::_('RSFP_COPERNICA_API_MISSING_CREDENTIALS'));
            } else {
                require_once(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_rsform' . DS . 'helpers' . DS . 'copernica_soapclient.php');

                try {
                    $copernicaApi = new PomSoapClient("http://publisher.copernica.nl/", $copernica_username, $copernica_account, $copernica_password);
                    $copernicaApiConnected = 1;
                } catch (Exception $e) {
                    JError::raiseWarning(500, '(Copernica) ' . JText::_('RSFP_COPERNICA_API_BAD_CREDENTIALS'));
                    $copernicaApiConnected = 0;
                    return;
                }
            }

            list($replace, $with) = RSFormProHelper::getReplacements($SubmissionId);

            $row->co_merge_vars = @unserialize($row->co_merge_vars);
            if ($row->co_merge_vars === false) {
                $row->co_merge_vars = array();
            }

            $row->co_merge_vars_update = @unserialize($row->co_merge_vars_update);
            if ($row->co_merge_vars_update === false) {
                $row->co_merge_vars_update = array();
            }

            $row->co_merge_vars_ignore = @unserialize($row->co_merge_vars_ignore);
            if ($row->co_merge_vars_ignore === false) {
                $row->co_merge_vars_ignore = array();
            }

            $row->co_merge_vars_key = @unserialize($row->co_merge_vars_key);
            if ($row->co_merge_vars_key === false) {
                $row->co_merge_vars_key = array();
            }

            $form = JRequest::getVar('form');
            $sIgnoreText = JText::_('RSFP_COPERNICA_API_MAPPING_IGNORE');

            $merge_vars = array();
            foreach ($row->co_merge_vars as $tag => $field) {

                if ($field == $sIgnoreText) {
                    continue;
                }

                if ($field == 'Form ID') {
                    $form[$field] = $formId;
                }
                if ($field == 'Submission ID') {
                    $form[$field] = $SubmissionId;
                }

                if (!isset($form[$field])) {
                    $form[$field] = '';
                }

                if (is_array($form[$field])) {
                    array_walk($form[$field], array('plgSystemRSFPCopernica', '_escapeCommas'));
                    $form[$field] = implode(',', $form[$field]);
                }

                $merge_vars[$tag] = $form[$field];
            }

            $list_id = $row->co_form_list_id;

            // Then we need to check if there a key field in the selected copernica db               
            $parameters = array('id' => $list_id);

            if ($copernicaApiConnected) {
                $oCopernicaDatabaseFields = $copernicaApi->Database_fields($parameters);

                $aMatchedFields = array();
                $aUpdateArray = array();
                $aDBFieldArray = array();

                foreach ($oCopernicaDatabaseFields->items as $oCopernicaDatabaseField) {
                    // check if this field is also in the form submit. 
                    if (isset($merge_vars[$oCopernicaDatabaseField->id]) && $merge_vars[$oCopernicaDatabaseField->id] != '') {
                        $aUpdateArray[$oCopernicaDatabaseField->name] = $merge_vars[$oCopernicaDatabaseField->id];
                        $aDBFieldArray[$oCopernicaDatabaseField->id] = $oCopernicaDatabaseField->name;
                    }

                    foreach ($row->co_merge_vars_key as $k => $v) {
                        if ($k == $oCopernicaDatabaseField->id) {
                            $aMatchedFields[$oCopernicaDatabaseField->id] = $oCopernicaDatabaseField->name;
                        }
                    }
                }
            } else {
                // No database connection. Quit!
                return;
            }

            try {
                if (count($aMatchedFields) > 0) {
                    // Let's build the requirements array for Copernica
                    $aRequirements = array();
                    foreach ($aMatchedFields as $sMatchKey => $sMatchValue) {
                        $aRequirements[] = $copernicaApi->toObject(array(
                            'fieldname' => $sMatchValue,
                            'value' => $merge_vars[$sMatchKey],
                            'operator' => 'LIKE',
                            'casesensitive' => 0
                                ));
                    }

                    // Let's try and find a profile with this data
                    $aUpdateprofiles = $copernicaApi->Database_searchProfiles(array(
                        'id' => $list_id,
                        'allproperties' => 1,
                        'requirements' => $aRequirements
                            ));
                }

                if ($aUpdateprofiles->total > 0) {

                    // We found profiles so let's update
                    foreach ($aUpdateprofiles->items as $profile) {

                        // Check if we have add to existing values set
                        if (count($row->co_merge_vars_update) > 0) {
                            foreach ($row->co_merge_vars_update as $k => $v) {
                                if (isset($aUpdateArray[$aDBFieldArray[$k]]) && $aUpdateArray[$aDBFieldArray[$k]] != '' && $v == 1) {
                                    foreach ($profile->fields->pair as $pk => $pv) {
                                        if ($pv->key == $aDBFieldArray[$k]) {
                                            if ($pv->value != '') {
                                                $pv->value = $pv->value . '+';
                                            }
                                            $aUpdateArray[$aDBFieldArray[$k]] = $pv->value . $aUpdateArray[$aDBFieldArray[$k]];
                                        }
                                    }
                                }
                            }
                        }

                        // Check if we have ignore values
                        if (count($row->co_merge_vars_ignore) > 0) {
                            foreach ($row->co_merge_vars_ignore as $k => $v) {
                                if (isset($aUpdateArray[$aDBFieldArray[$k]]) && $aUpdateArray[$aDBFieldArray[$k]] != '' && $v == 1) {
                                    foreach ($profile->fields->pair as $pk => $pv) {
                                        if ($pv->key == $aDBFieldArray[$k]) {
                                            if ($pv->value != '') {
                                                $aUpdateArray[$aDBFieldArray[$k]] = $pv->value;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        $copernicaApi->Profile_updateFields(array(
                            'id' => $profile->id,
                            'fields' => $aUpdateArray
                        ));
                    }
                } else {
                    // We didn't find anything so let's create a new profile 
                    $profileResult = $copernicaApi->Database_createProfile(array(
                        'id' => $list_id,
                        'fields' => $aUpdateArray
                            ));
                }
            } catch (Exception $e) {
                print_r($e);
            }
        }
    }

    function rsfp_bk_onAfterShowConfigurationTabs() {
        if (!$this->canRun())
            return;

        $lang = & JFactory::getLanguage();
        $lang->load('plg_system_rsfpcopernica');

        jimport('joomla.html.pane');
        $tabs = & JPane::getInstance('Tabs', array(), true);

        echo $tabs->startPanel(JText::_('Copernica'), 'form-copernica');
        $this->copernicaConfigurationScreen();
        echo $tabs->endPanel();
    }

    function copernicaConfigurationScreen() {
        if (!$this->canRun()) {
            return;
        }

        $lang = & JFactory::getLanguage();
        $lang->load('plg_system_rsfpcopernica');
        ?>
        <div id="page-recaptcha">
            <table class="admintable">
                <tr>
                    <td width="200" style="width: 200px;" align="right" class="key"><label for="copernica_api_accountname"><span class="hasTip" title="<?php echo JText::_('RSFP_COPERNICA_API_ACCOUNTNAME_DESC'); ?>"><?php echo JText::_('RSFP_COPERNICA_API_ACCOUNTNAME'); ?></span></label></td>
                    <td><input type="text" name="rsformConfig[copernica.api_accountname]" id="copernica_api_accountname" value="<?php echo RSFormProHelper::htmlEscape(RSFormProHelper::getConfig('copernica.api_accountname')); ?>" size="100" maxlength="100"></td>
                </tr>
                <tr>
                    <td width="200" style="width: 200px;" align="right" class="key"><label for="copernica_api_username"><span class="hasTip" title="<?php echo JText::_('RSFP_COPERNICA_API_USERNAME_DESC'); ?>"><?php echo JText::_('RSFP_COPERNICA_API_USERNAME'); ?></span></label></td>
                    <td><input type="text" name="rsformConfig[copernica.api_username]" id="copernica_api_username" value="<?php echo RSFormProHelper::htmlEscape(RSFormProHelper::getConfig('copernica.api_username')); ?>" size="100" maxlength="100"></td>
                </tr>
                <tr>
                    <td width="200" style="width: 200px;" align="right" class="key"><label for="copernica_api_password"><span class="hasTip" title="<?php echo JText::_('RSFP_COPERNICA_API_PASSWORD_DESC'); ?>"><?php echo JText::_('RSFP_COPERNICA_API_PASSWORD'); ?></span></label></td>
                    <td><input type="text" name="rsformConfig[copernica.api_password]" id="copernica_api_password" value="<?php echo RSFormProHelper::htmlEscape(RSFormProHelper::getConfig('copernica.api_password')); ?>" size="100" maxlength="100"></td>
                </tr>
            </table>
        </div>
        <?php
    }

    function _getFields($formId) {
        $db = JFactory::getDBO();

        $db->setQuery("SELECT p.PropertyValue FROM #__rsform_components c LEFT JOIN #__rsform_properties p ON (c.ComponentId=p.ComponentId) WHERE c.FormId='" . (int) $formId . "' AND p.PropertyName='NAME' ORDER BY c.Order");
        $fields = $db->loadResultArray();

        $sIgnoreText = JText::_('RSFP_COPERNICA_API_MAPPING_IGNORE');
        array_unshift($fields, $sIgnoreText, 'Form ID', 'Submission ID');

        return $fields;
    }

    function _escapeCommas(&$item) {
        $item = str_replace(',', '\,', $item);
    }

    function rsfp_bk_onSwitchTasks() {
        $formId = JRequest::getInt('formId');

        $lang = & JFactory::getLanguage();
        $lang->load('plg_system_rsfpcopernica');

        $row = JTable::getInstance('RSForm_Copernica', 'Table');
        if (!$row) {
            return;
        }
        $row->load($formId);

        $row->co_merge_vars = @unserialize($row->co_merge_vars);
        if ($row->co_merge_vars === false) {
            $row->co_merge_vars = array();
        }

        $row->co_merge_vars_update = @unserialize($row->co_merge_vars_update);
        if ($row->co_merge_vars_update === false) {
            $row->co_merge_vars_update = array();
        }

        $row->co_merge_vars_ignore = @unserialize($row->co_merge_vars_ignore);
        if ($row->co_merge_vars_ignore === false) {
            $row->co_merge_vars_ignore = array();
        }

        $row->co_merge_vars_key = @unserialize($row->co_merge_vars_key);
        if ($row->co_merge_vars_key === false) {
            $row->co_merge_vars_key = array();
        }

        $plugin_task = JRequest::getVar('co_plugin_task');
        switch ($plugin_task) {
            case 'get_merge_vars':

                if ((int) $row->co_form_credentials == 1) {
                    $copernica_account = RSFormProHelper::getConfig('copernica.api_accountname');
                    $copernica_username = RSFormProHelper::getConfig('copernica.api_username');
                    $copernica_password = RSFormProHelper::getConfig('copernica.api_password');
                } else {
                    $copernica_account = $row->co_form_accountname;
                    $copernica_username = $row->co_form_username;
                    $copernica_password = $row->co_form_password;
                }

                $copernicaApi = '';
                $copernicaApiConnected = 0;
                if ((int) $row->co_form_credentials == 1 && ($copernica_account == '' || $copernica_username == '' || $copernica_password == '')) {
                    JError::raiseWarning(500, '(Copernica) ' . JText::_('RSFP_COPERNICA_API_MISSING_CREDENTIALS'));
                } else {
                    require_once(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_rsform' . DS . 'helpers' . DS . 'copernica_soapclient.php');

                    try {
                        $copernicaApi = new PomSoapClient("http://publisher.copernica.nl/", $copernica_username, $copernica_account, $copernica_password);
                        $copernicaApiConnected = 1;
                    } catch (Exception $e) {
                        $copernicaApiConnected = 0;
                    }
                }

                // Get all database fields from Copernica for a specific database ID
                $parameters = array(
                    'id' => JRequest::getVar('list_id')
                );
                if ($copernicaApiConnected) {
                    $oCopernicaDatabaseFields = $copernicaApi->Database_fields($parameters);
                } else {
                    $oCopernicaDatabaseFields = new stdClass();
                    $oCopernicaDatabaseFields->total = 0;
                }

                if ($oCopernicaDatabaseFields->total > 0) {
                    $resultCounter = 0;
                    foreach ($oCopernicaDatabaseFields->items as $oCopernicaDatabaseField) {
                        echo $oCopernicaDatabaseField->id . "\n";
                        echo $oCopernicaDatabaseField->name;

                        if ($resultCounter < ($oCopernicaDatabaseFields->total - 1)) {
                            echo "\n";
                        }
                    }
                    $resultCounter++;
                }
                jexit();
                break;
        }
    }
}