DELETE FROM `#__rsform_config` WHERE `SettingName` IN ('copernica.api_accountname', 'copernica.api_username', 'copernica.api_password');

INSERT IGNORE INTO `#__rsform_config` (`ConfigId`, `SettingName`, `SettingValue`) VALUES ('', 'copernica.api_accountname', '');
INSERT IGNORE INTO `#__rsform_config` (`ConfigId`, `SettingName`, `SettingValue`) VALUES ('', 'copernica.api_username', '');
INSERT IGNORE INTO `#__rsform_config` (`ConfigId`, `SettingName`, `SettingValue`) VALUES ('', 'copernica.api_password', '');

CREATE TABLE IF NOT EXISTS `#__rsform_copernica` (
  `form_id` int(11) NOT NULL,
  `co_form_active` tinyint(1) NOT NULL,
  `co_form_list_id` varchar(16) NOT NULL,
  `co_form_credentials` tinyint(1) NOT NULL,
  `co_form_username` varchar(255) NOT NULL,
  `co_form_accountname` varchar(255) NOT NULL,
  `co_form_password` varchar(255) NOT NULL,
  `co_merge_vars` text NOT NULL,
  `co_merge_vars_update` text NOT NULL,  
  `co_merge_vars_ignore` text NOT NULL,  
  `co_merge_vars_key` text NOT NULL,  
  PRIMARY KEY  (`form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;