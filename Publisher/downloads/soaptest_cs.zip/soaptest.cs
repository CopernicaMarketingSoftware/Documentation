using System;

namespace Soaptest
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create the Web Reference object.
            api.POM_SOAP_API pom = new api.POM_SOAP_API();

            // Make sure the Web Service send back cookies. Otherwise we aren't logged in after the login request.
            pom.CookieContainer = new System.Net.CookieContainer();

            // Enable compression
            pom.EnableCompression = true;

            // Create a new login parameter object
            api.input_login login_parameters = new api.input_login();
            login_parameters.account = "Account";
            login_parameters.username = "Gebruiker";
            login_parameters.password = "********";

            // Use the try .. catch system to login.
            try
            {
                // Login using the login parameters
                pom.login(login_parameters);

                // We arrive here when the login has been a succes.
                Console.WriteLine("Logged in.");
            }
            catch (Exception ex)
            {
                // The login was wrong and threw a exception, that's why we arrived here.
                // We print the error message to get some feedback.
                Console.WriteLine(ex.Message);
            }

            // Create database 'Fictional Persons'        
            api.input_Account_createDatabase parameters = new api.input_Account_createDatabase();
            parameters.name = "Fictional Persons";                      // The name of the future database.
            api.Result result = pom.Account_createDatabase(parameters); // Execute the command and store the result.

            // Retrieve the newly created database from the Result object.
            api.Database database = result.database;

            // Create fields for the database
            api.input_Database_createField field = new api.input_Database_createField();

            // Create the first name field.
            field.id = database.id;  // Give the Database id, so the field get's created inside the new database
            field.name = "FirstName";           // Setup the field name
            field.displaySpecified = field.display = true; // Make it appear on the overview (in the web application)                
            pom.Database_createField(field);    // Create the field.

            // Create the first name field.
            field.id = database.id;  // Give the Database id, so the field get's created inside the new database
            field.name = "LastName";            // Setup the field name
            field.displaySpecified = field.display = true; // Make it appear on the overview (in the web application)                
            pom.Database_createField(field);    // Create the field.
            
            // Create the first name field.
            field.id = database.id;  // Give the Database id, so the field get's created inside the new database
            field.name = "Email";               // Setup the field name
            field.displaySpecified = field.display = true; // Make it appear on the overview (in the web application)                
            field.specialcontent = "email";     // Make sure it's an E-mail field, so we can send mailings.
            pom.Database_createField(field);    // Create the field.

            // Create a fictional person.
            api.input_Database_createProfile profile = new api.input_Database_createProfile();
            profile.id = database.id;    // Give the Database id, so the person get's created inside the new database

            // We need to create for each field a Pair object.
            api.Pair pair1 = new api.Pair();
            api.Pair pair2 = new api.Pair();
            api.Pair pair3 = new api.Pair();

            pair1.key = "FirstName";          // The key would be the name of the field.
            pair1.value = "Piet";             // The value would be the value of the field.

            pair2.key = "LastName";           // The key would be the name of the field.
            pair2.value = "Papier";           // The value would be the value of the field.

            pair3.key = "Email";              // The key would be the name of the field.
            pair3.value = "piet@papier.nl";   // The value would be the value of the field.

            // Add the pairs to the profile
            profile.fields = new api.Pair[] { pair1, pair2, pair3 };

            // And finally; Create the profile.
            result = pom.Database_createProfile(profile);
            
            // Save the first profile from the results.
            api.Profile profile1 = result.profile;

            // Create a second fictional person.
            profile = new api.input_Database_createProfile();
            profile.id = database.id;

            // We need to create for each field a Pair object.
            pair1 = new api.Pair();
            pair2 = new api.Pair();
            pair3 = new api.Pair();

            pair1.key = "FirstName";          // The key would be the name of the field.
            pair1.value = "Ed";               // The value would be the value of the field.

            pair2.key = "LastName";           // The key would be the name of the field.
            pair2.value = "Emmer";            // The value would be the value of the field.

            pair3.key = "Email";              // The key would be the name of the field.
            pair3.value = "ed@emmer.nl";      // The value would be the value of the field.

            // Add the pairs to the profile
            profile.fields = new api.Pair[] { pair1, pair2, pair3 };

            // And finally; Create the profile.
            result = pom.Database_createProfile(profile);

            // Save the second profile from the results.
            api.Profile profile2 = result.profile;

            // Remove the profile 2 (Ed Emmer).
            api.input_Profile_remove removeparameters = new api.input_Profile_remove();
            removeparameters.id = profile2.id;      // set the id of the profile that will be removed.
            pom.Profile_remove(removeparameters);   // execute call

            // Update the profile 1 (Piet Papier).
            api.input_Profile_updateFields updateparameters = new api.input_Profile_updateFields();
            updateparameters.id = profile1.id;     // set the id of the profile that will be updated.

            // The fields are given trough a Map object. A map consists of multiple Pair objects.

            // We need to create for each field a Pair object.
            pair1 = new api.Pair();
            pair1.key = "Email";
            pair1.value = "piet.papier@example.com";

            // Add the field array to the update paramaters.
            updateparameters.fields = new api.Pair[] { pair1 };

            // Update the profile.
            pom.Profile_updateFields(updateparameters);
        }
    }
}
